"""
    该函数将算法生成的动作赋予CAV，对当前交通环境状态进行更新；
    同时存储更新后的状态信息，作为算法训练及场景更新的依据。
    -本程序包括针对Merging场景的状态更新算法
"""

import torch
import traci
import math
import numpy as np
from sklearn.metrics.pairwise import euclidean_distances


# 该函数为CAV动作执行函数（不同区域对应不同换道函数）
def action_apply_intersection(action, ID, param):
    if action == 0:  # 加速
        current_speed = traci.vehicle.getSpeed(ID)
        target_speed = current_speed + param['Delta_speed'] \
                       * param['Kp'] * param['Sim_step']
        np.clip(target_speed, 0, param['Max_speed_AV'])
        traci.vehicle.setSpeedMode(ID, 0b0100110)
        traci.vehicle.setSpeed(ID, target_speed)
    elif action == 1:  # 减速
        current_speed = traci.vehicle.getSpeed(ID)
        target_speed = current_speed - param['Delta_speed'] \
                       * param['Kp'] * param['Sim_step']
        np.clip(target_speed, 0, param['Max_speed_AV'])
        traci.vehicle.setSpeedMode(ID, 0b0100110)
        traci.vehicle.setSpeed(ID, target_speed)
    elif action == 2:  # 保持
        return
    elif action == 3:  # 左换道（车道编号+1）
        current_lane = traci.vehicle.getLaneIndex(ID)
        next_lane = np.clip(current_lane + 1, 0, 1)
        traci.vehicle.setLaneChangeMode(ID, 0b000000000100)
        traci.vehicle.changeLane(ID, next_lane, 0.5)
    elif action == 4:  # 右换道（车道编号-1）
        current_lane = traci.vehicle.getLaneIndex(ID)
        next_lane = np.clip(current_lane - 1, 0, 1)
        traci.vehicle.setLaneChangeMode(ID, 0b000000000100)
        traci.vehicle.changeLane(ID, next_lane, 0.5)




# 该函数用来定义奖励函数，并计算奖励值
def compute_reward_intersection(state_next, param, lane_change_record):
    """
        碰撞、速度、驾驶意图
    """
    # 上述五项奖励权重
    wc = 200
    wv = 4
    wd = 1
    wl = 0
    wi = 4
    lane_change_threshold = 3

    # 环境信息
    L_in = 49.6

    # 获取id信息
    ID_AVs = state_next['ID_AVs']

    # 计算碰撞惩罚
    rc = 0
    crash_event = traci.simulation.getCollisions()
    max_v = param['Max_speed_AV']
    if crash_event:
        for elem in crash_event:
            if traci.vehicle.getTypeID(elem.collider) == 'CAV':
                rc = rc - 1
    # crash_event = traci.simulation.getCollisions()
    # if crash_event:
    #     for elem in crash_event:
    #         if traci.vehicle.getTypeID(elem.collider) == 'CAV':
    #             rc = rc - 1

    # 计算速度奖励
    max_v = param['Max_speed_AV']
    v_cav = np.array(state_next['Vel_x'])[:len(ID_AVs)]
    v_cav_normalized = v_cav / max_v
    rv_matrix = [min(elem, 1) for elem in v_cav_normalized]
    rv = sum(rv_matrix)

    # 使用同一个循环，计算车距保持奖励及频繁换道惩罚
    drastic_vel = np.zeros(param['n_av'])
    # rd = 0
    rl = 0
    ri = 0
    for ind, veh_id in enumerate(ID_AVs):
        # 这部分计算车距保持奖励（基于与前车的距离）
        # leader = traci.vehicle.getLeader(veh_id)
        # if leader and v_cav[ind] != 0:
        #     leading_distance = np.clip(abs(leader[1]), 0.5, 200)
        #     rd_cav_i = math.log(leading_distance / (v_cav[ind] * param['th']))
        #     rd = rd + rd_cav_i

        # 这部分通过计算当前时间以及最后一次换道的时间间隔来检测车辆是否有激烈换道行为
        # 需要注意的是，这部分需要从车辆出现两次换道行为后开始计算
        # if lane_change_record[ind, 0] != 0 and lane_change_record[ind, 1] != 0:
        #     lane_change_time = lane_change_record[ind, 1] \
        #                        - lane_change_record[ind, 0]
        #     if lane_change_time < lane_change_threshold:
        #         # rl = rl - 1
        #         drastic_vel[ind] = 1

        # 计算路口驶入路段长时间行驶惩罚
        if traci.vehicle.getLaneID(veh_id) == '-E2_0':  # 如果车辆处在汇流路段
            Pos_x_cav = state_next['Pos_y'][ind] + L_in
            ri = ri - Pos_x_cav / L_in

    reward = wc * rc + wv * rv + wi * ri

    return reward, drastic_vel, [wc * rc, wv * rv, wi * ri]


# 该函数用来执行强化学习算法生成的动作，并进行状态更新
def step_tintersection(rl_actions, param, lane_change_record, t):
    """
        状态空间：纵向相对位置，横向相对位置，纵向车速，横向车速
        动作空间：加速，减速，状态保持，左换道，右换道（动作编号对应0,1,2,3,4）
        仿真器车辆种类：CAV（被控车辆），HV
    """

    # 获取环境中车辆id
    ids = traci.vehicle.getIDList()
    exist_V = []
    for num in range(len(traci.simulation.getArrivedIDList())):
        exist_V.append(traci.simulation.getArrivedIDList()[num])

    # 动作执行
    if isinstance(rl_actions, torch.Tensor):
        rl_actions = rl_actions.cpu().numpy()
    # 按照动作矩阵的存储顺序将动作值赋予对应编号的CAV
    count_CAV = 0
    if t >= param['time_length']:  # 如果观测序列长度满足，则执行RL动作
        for ID in ids:
            Vehicle_type = traci.vehicle.getTypeID(ID)  # 获取车辆种类
            if Vehicle_type == "CAV":
                # 确定需要执行的动作
                action_executed = rl_actions[count_CAV]
                # 动作执行（关键函数）
                action_apply_intersection(action_executed, ID, param)
                count_CAV += 1

    # 仿真器状态更新
    traci.simulationStep()

    # 获取更新后的状态信息
    ID_AVs = []
    ID_HVs = []
    Pos = []
    Pos_x = []
    Pos_y = []
    Vel_x = []
    Vel_y = []
    Acc = []
    Current_lane = []
    Travel_distance = []

    # 获取评价指标相关信息
    collision_num = 0  # 碰撞相关
    average_speed = 0  # 平均车速相关

    # 记录各项奖励值
    reward_test = [0, 0, 0, 0, 0]

    ids = traci.vehicle.getIDList()  # 重新获取环境中车辆ID信息
    ids = sorted(ids)
    for ID in ids:  # 进行信息存储
        # 储存编号信息
        if traci.vehicle.getTypeID(ID) == 'CAV':
            ID_AVs.append(ID)
        elif traci.vehicle.getTypeID(ID) == 'HV':
            ID_HVs.append(ID)

        # 储存状态信息
        position = traci.vehicle.getPosition(ID)
        Pos.append(position)
        Pos_x.append(position[0])
        Pos_y.append(position[1])

        Vel_x.append(traci.vehicle.getSpeed(ID))
        Vel_y.append(traci.vehicle.getLateralSpeed(ID))

        Acc.append(traci.vehicle.getAcceleration(ID))

        Current_lane.append(traci.vehicle.getLaneIndex(ID))

        Travel_distance.append(traci.vehicle.getDistance(ID))

    # 计算评价指标相关信息
    # 碰撞系数
    collision_num = traci.simulation.getCollidingVehiclesNumber() / 2

    # 平均车速
    if ID_AVs:
        average_speed = sum(Vel_x[:len(ID_AVs)]) / len(ID_AVs)

    # 储存所有信息
    state_next = {'ids': ids,
                  'ID_AVs': ID_AVs,
                  'ID_HVs': ID_HVs,
                  'Pos': Pos,
                  'Pos_x': Pos_x,
                  'Pos_y': Pos_y,
                  'Vel_x': Vel_x,
                  'Vel_y': Vel_y,
                  'Acc': Acc,
                  'Current_lane': Current_lane,
                  'Travel_distance': Travel_distance,
                  'collision_num': collision_num,
                  'average_speed': average_speed,
                  'lane_change_time': 0,
                  'reward_test': [0, 0, 0, 0, 0]
                  }

    # 如果环境中存在cav，则计算奖励值
    reward = 0
    drastic_vel = np.zeros(param['n_av'])
    if ID_AVs:
        reward, drastic_vel, reward_test = compute_reward_intersection(state_next, param, lane_change_record)
        # print(reward_test)

    state_next['lane_change'] = drastic_vel
    state_next['reward_test'] = reward_test

    return state_next, reward 
