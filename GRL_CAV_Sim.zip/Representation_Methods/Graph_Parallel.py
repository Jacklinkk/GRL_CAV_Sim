"""
    该函数用来获得环境的图表征
    -典型图表征方法（无任何改进）
    -预期包含各个典型交通场景的图表征算法

    特征说明：
    SUMO获取车辆编号时具有自动排序功能。
    构建仿真环境时，车辆分为CAV和HV两种，编号中CAV排在HV前面。
    因此特征矩阵为[CAV1,CAV2,...,HV1,HV2,...]，可按照此规律快速获取对应车辆的特征信息
"""

import numpy as np
import traci
from sklearn.metrics.pairwise import euclidean_distances


# 根据环境更新的信息构造下一时间步的图表征
def get_feature_merging(state_next, param):
    # 获取仿真基本参数
    N = param['n_vehicles']
    num_av = param['n_av']
    num_hv = param['n_hv']  # maximum number of HDVs
    feature_length = param['Feature_length']
    observe_range = param['Observe_range']
    observe_num = param['Observe_num']
    communication_distance = param['Communication_distance']

    # 获取更新后的环境信息
    ids = state_next['ids']
    ID_AVs = state_next['ID_AVs']
    ID_HVs = state_next['ID_HVs']
    Pos = state_next['Pos']
    Pos_x = np.array(state_next['Pos_x'])
    Pos_y = np.array(state_next['Pos_y'])
    Vel_x = np.array(state_next['Vel_x'])
    Vel_y = np.array(state_next['Vel_y'])

    # 初始化节点特征矩阵，邻接矩阵
    node_feature_matrix = np.zeros([num_av + num_hv, feature_length])
    adjacency_matrix = np.zeros([num_av + num_hv, num_av + num_hv])
    mask = np.zeros(num_av + num_hv)

    # ------测试程序------ #
    if ID_AVs:
        """
            1.构造节点特征矩阵
        """
        # n_total = len(ID_AVs) + len(ID_HVs)

        # 特征数据维度调整（CAV+HV）
        Pos_x = Pos_x.reshape(-1, 1)
        Pos_y = Pos_y.reshape(-1, 1)
        Vel_x = Vel_x.reshape(-1, 1)
        Vel_y = Vel_y.reshape(-1, 1)

        # 构造特征向量
        observed_states = np.c_[Pos_x, Pos_y, Vel_x, Vel_y]

        # 构造节点特征矩阵
        node_feature_matrix[:len(ID_AVs), :] = observed_states[:len(ID_AVs), :]
        node_feature_matrix[num_av:num_av + len(ID_HVs), :] = observed_states[len(ID_AVs):, :]

        """
            2.构造邻接矩阵
        """
        # 计算车辆之间距离
        distance_between_v = euclidean_distances(Pos)

        # 按照通信距离为邻接矩阵赋值
        adjacency_matrix_small = np.zeros_like(distance_between_v)
        adjacency_matrix_small[distance_between_v < communication_distance] = 1

        # 构造邻接矩阵
        adjacency_matrix[:len(ID_AVs), :len(ID_AVs)] = adjacency_matrix_small[:len(ID_AVs), :len(ID_AVs)]

        adjacency_matrix[:len(ID_AVs), num_av:num_av + len(ID_HVs)] \
            = adjacency_matrix_small[:len(ID_AVs), len(ID_AVs):]

        adjacency_matrix[num_av:num_av + len(ID_HVs), :len(ID_AVs)] \
            = adjacency_matrix_small[len(ID_AVs):, :len(ID_AVs)]

        adjacency_matrix[num_av:num_av + len(ID_HVs), num_av:num_av + len(ID_HVs)] \
            = adjacency_matrix_small[len(ID_AVs):, len(ID_AVs):]

        """
            3.构造mask矩阵
        """
        mask[:len(ID_AVs)] = np.ones(len(ID_AVs))

    return node_feature_matrix, adjacency_matrix, mask
