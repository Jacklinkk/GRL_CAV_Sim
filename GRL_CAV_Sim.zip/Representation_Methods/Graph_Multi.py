"""
    该函数用来获得环境的图表征
    -典型图表征方法（无任何改进）
    -预期包含各个典型交通场景的图表征算法

    特征说明：
    SUMO获取车辆编号时具有自动排序功能。
    构建仿真环境时，车辆分为CAV和HV两种，编号中CAV排在HV前面。
    因此特征矩阵为[CAV1,CAV2,...,HV1,HV2,...]，可按照此规律快速获取对应车辆的特征信息
"""
import math

import numpy as np
import traci
from sklearn.metrics.pairwise import euclidean_distances
from sklearn.preprocessing import MinMaxScaler


# 将矩阵上三角赋值给下三角，减少邻接矩阵计算量
def copy_upper_to_lower(matrix):
    n = len(matrix)
    for i in range(n):
        for j in range(i + 1, n):
            matrix[j][i] = matrix[i][j]


def TTC_model(distance_x_i, vel_x_i, length_vel, t_pre):
    """
        TTC是典型模型，表示主车不采取制动情况下与前车碰撞时间
        计算该模型需要如下参数：
        -两车相对位置，相对速度
        -前车长度
    """
    if vel_x_i > 0:
        risk_value = (distance_x_i - length_vel) / vel_x_i
    else:
        risk_value = 0

    if 0 < risk_value < t_pre:
        risk_value = 1
    else:
        risk_value = 0

    return risk_value


# 构造判断轨迹是否相交的函数
def cross_product(p1, p2, q1):
    return (p2[0] - p1[0]) * (q1[1] - p1[1]) - (p2[1] - p1[1]) * (q1[0] - p1[0])


def do_segments_intersect(p1, p2, q1, q2):
    cp1 = cross_product(p1, p2, q1)
    cp2 = cross_product(p1, p2, q2)
    cp3 = cross_product(q1, q2, p1)
    cp4 = cross_product(q1, q2, p2)

    # 如果存在异号的叉积结果，则线段相交
    return (cp1 * cp2 < 0) and (cp3 * cp4 < 0)


# 根据环境更新的信息构造下一时间步的图表征
def get_feature_merging(state_next, param, action_list):
    # 获取仿真基本参数
    N = param['n_vehicles']
    num_av = param['n_av']
    num_hv = param['n_hv']  # maximum number of HDVs
    feature_length = param['Feature_length']
    observe_range = param['Observe_range']
    observe_num = param['Observe_num']
    communication_distance = param['Communication_distance']
    communication_loss_rate = param['com_loss']
    T_pre = 3  # 构造安全矩阵时，轨迹预测的时间步长
    Length_vel = 5  # 车身长度
    gamma = 0.95  # 动作序列折扣系数

    # 获取更新后的环境信息
    ids = state_next['ids']
    ID_AVs = state_next['ID_AVs']
    ID_HVs = state_next['ID_HVs']
    Pos = state_next['Pos']
    Pos_x = np.array(state_next['Pos_x'])
    Pos_y = np.array(state_next['Pos_y'])
    Vel_x = np.array(state_next['Vel_x'])
    Vel_y = np.array(state_next['Vel_y'])

    # 初始化节点特征矩阵，邻接矩阵
    node_feature_matrix = np.zeros([num_av, feature_length * (observe_num + 1)])

    adjacency_matrix_communication = np.zeros([num_av, num_av])
    adjacency_matrix_safety = np.zeros([num_av, num_av])
    adjacency_matrix_action = np.zeros([num_av, num_av])
    # mask = np.zeros(N)

    adjacency_matrix = {'communication': adjacency_matrix_communication,
                        'safety': adjacency_matrix_safety,
                        'action': adjacency_matrix_action}

    # ------测试程序------ #
    if len(ID_AVs):
        L_cav = len(ID_AVs)
        """
            1.构造节点特征矩阵
        """
        # 位置及距离计算（这里返回的是numpy数据类型）
        distance = euclidean_distances(Pos)  # 计算环境中每两辆车之间的距离
        distance_cav = distance[:L_cav]  # 获取以CAV为参照的距离

        # distance_x = euclidean_distances(Pos_x)  # 计算环境中每两辆车之间的纵向相对位置
        # distance_y = euclidean_distances(Pos_y)  # 计算环境中每两辆车之间的横向相对位置
        # distance_x_cav = np.array(distance_x[:L_cav])  # 获取以CAV为参照的纵向相对位置
        # distance_y_cav = np.array(distance_y[:L_cav])  # 获取以CAV为参照的横向相对位置距离

        # 针对CAV构造特征向量
        for cav_i in range(0, L_cav):  # 针对每辆cav进行特征操作
            # 判断感知范围内周车数目，并获取需存储的车辆索引
            index = np.where((observe_range > distance_cav[cav_i]) & (distance_cav[cav_i] > 0))[0]  # 获取感知范围内所有车辆索引
            if len(index) > observe_num:  # 如果周车数目大于观测数目
                # 按照距离排序并选择依照距离选择观测车辆
                distance_cav_new = sorted(distance_cav[cav_i])[1: observe_num]
                # 在原数组中找到最近距离车辆的索引编号，并更新
                index_new = [np.where(distance_cav[cav_i] == elem)[0] for elem in distance_cav_new]
                index_new = np.concatenate(index_new)
            else:
                index_new = index

            # ------考虑通讯（感知）失效，去除通讯失效的车辆------ #
            communication_loss_sense = np.random.random(len(index_new))
            communication_matrix_sense = np.ones_like(communication_loss_sense)
            communication_matrix_sense[communication_loss_sense >
                                       1 - communication_loss_rate] = 0
            # 移除通讯损失的车辆索引，不参与后续特征处理与计算
            loss_vehicles = np.where(communication_matrix_sense == 0)[0]
            index_new = np.delete(index_new, loss_vehicles)

            # 依照上述生成的新索引构造cav_i的特征向量[ego,x_i,y_i,vel_x_i,vel_y_i]，并进行拼接
            # if len(index_new):
            #     distance_x_i = (Pos_x[index_new] - Pos_x[cav_i]).reshape(-1, 1)
            #     distance_y_i = (Pos_y[index_new] - Pos_y[cav_i]).reshape(-1, 1)
            #     vel_x_i = (Vel_x[index_new] - Vel_x[cav_i]).reshape(-1, 1)
            #     vel_y_i = (Vel_y[index_new] - Vel_y[cav_i]).reshape(-1, 1)
            #     # 构建周车特征
            #     feature_cav_surrounding = np.c_[distance_x_i, distance_y_i, vel_x_i, vel_y_i]
            #     feature_cav_surrounding = np.reshape(feature_cav_surrounding, (1, len(index_new) * feature_length))
            #     # 构建自车特征
            #     feature_cav_ego = np.c_[Pos_x[cav_i], Pos_y[cav_i], Vel_x[cav_i], Vel_y[cav_i]]
            #     # 特征拼接
            #     feature_cav_i = np.c_[feature_cav_ego, feature_cav_surrounding]
            # else:
            #     feature_cav_i = np.c_[Pos_x[cav_i], Pos_y[cav_i], Vel_x[cav_i], Vel_y[cav_i]]

            distance_x_i = (Pos_x[index_new] - Pos_x[cav_i]).reshape(-1, 1)
            distance_y_i = (Pos_y[index_new] - Pos_y[cav_i]).reshape(-1, 1)
            vel_x_i = (Vel_x[index_new] - Vel_x[cav_i]).reshape(-1, 1)
            vel_y_i = (Vel_y[index_new] - Vel_y[cav_i]).reshape(-1, 1)
            # 构建周车特征
            feature_cav_surrounding = np.c_[distance_x_i, distance_y_i, vel_x_i, vel_y_i]
            feature_cav_surrounding = np.reshape(feature_cav_surrounding, (1, len(index_new) * feature_length))
            # 构建自车特征
            feature_cav_ego = np.c_[Pos_x[cav_i], Pos_y[cav_i], Vel_x[cav_i], Vel_y[cav_i]]
            # 特征拼接
            feature_cav_i = np.c_[feature_cav_ego, feature_cav_surrounding]

            # 构建节点特征矩阵
            if feature_cav_i.size > 16:
                feature_cav_i = feature_cav_i[:, 0:16]
            node_feature_matrix[cav_i, :feature_cav_i.size] = feature_cav_i

        # 将节点特征矩阵按照cav在场景中的横坐标位置进行排序
        sorted_indices = node_feature_matrix[:, 0].argsort()
        node_feature_matrix = node_feature_matrix[sorted_indices]

        """
            2.1 构造通信矩阵
        """
        # 获取cav之间的距离
        Pos_cav = Pos[:L_cav]
        distance_between_cav = euclidean_distances(Pos_cav)
        distance_between_cav = distance_between_cav + np.eye(L_cav)
        # 按照通信距离为邻接矩阵赋值
        adjacency_matrix_small = np.zeros_like(distance_between_cav)
        adjacency_matrix_small[distance_between_cav < communication_distance] = 1
        adjacency_matrix_communication[:L_cav, :L_cav] = adjacency_matrix_small

        """
            2.2 构造安全矩阵（根据预测轨迹构造）
        """
        # 获取速度信息
        Vel_x_cav = Vel_x[:L_cav]
        Vel_y_cav = Vel_y[:L_cav]

        for i in range(L_cav):
            for j in range(i, L_cav):
                if j == i:
                    adjacency_matrix_safety[i][j] = 0
                elif Pos_cav[i][1] == Pos_cav[j][1]:  # 两辆车在同一车道
                    delta_d = Pos_cav[j][0] - Pos_cav[i][0]
                    delta_v = Vel_x_cav[i] - Vel_x_cav[j]
                    adjacency_matrix_safety[i][j] = TTC_model(delta_d, delta_v, Length_vel, T_pre)
                else:  # 其他情况
                    Pos_cav_i_pre = (Pos_cav[i] +
                                     np.array([Vel_x_cav[i] * T_pre,
                                               Vel_y_cav[i] * T_pre]))
                    Pos_cav_j_pre = (Pos_cav[j] +
                                     np.array([Vel_x_cav[j] * T_pre,
                                               Vel_y_cav[j] * T_pre]))
                    adjacency_matrix_safety[i][j] = do_segments_intersect(Pos_cav[i],
                                                                          Pos_cav_i_pre,
                                                                          Pos_cav[j],
                                                                          Pos_cav_j_pre)

        copy_upper_to_lower(adjacency_matrix_safety)

        """
            2.3 构造动作相似度矩阵
        """
        # 计算折扣系数
        length_gamma = param['time_length']
        gamma_matrix = [gamma ** i for i in range(0, length_gamma)]
        gamma_matrix.reverse()
        gamma_matrix = np.array(gamma_matrix)

        # 计算矩阵中的取值
        adjacency_matrix_small = np.zeros([L_cav, L_cav])
        for i in range(L_cav):
            for j in range(i, L_cav):
                a_norm = (action_list[i] - action_list[j]) * gamma_matrix
                adjacency_matrix_small[i][j] = np.linalg.norm(a_norm)

        copy_upper_to_lower(adjacency_matrix_small)

        # 将每一行大于该行平均值的元素设置为1
        row_averages = np.mean(adjacency_matrix_small, axis=1)
        result_matrix = np.zeros_like(adjacency_matrix_small, dtype=int)
        result_matrix[adjacency_matrix_small > row_averages[:, np.newaxis]] = 1

        adjacency_matrix_action[:L_cav, :L_cav] = result_matrix

        # ------考虑通讯（网联）失效，去除通讯失效的CAV------ #
        communication_matrix_cav = np.ones(num_av)
        communication_loss_cav = np.random.random(len(ID_AVs))
        communication_matrix_cav_small = np.ones_like(communication_loss_cav)
        # 构建通信失效矩阵
        communication_matrix_cav_small[communication_loss_cav >
                                       1 - communication_loss_rate] = 0
        communication_matrix_cav[:len(ID_AVs)] = communication_matrix_cav_small

        # 考虑网联失效，邻接矩阵对应位置的cav特征归零
        adjacency_matrix_communication = \
            adjacency_matrix_communication * communication_matrix_cav \
            * communication_matrix_cav.reshape(-1, 1)

        adjacency_matrix_safety = \
            adjacency_matrix_safety * communication_matrix_cav \
            * communication_matrix_cav.reshape(-1, 1)

        adjacency_matrix_action = \
            adjacency_matrix_action * communication_matrix_cav \
            * communication_matrix_cav.reshape(-1, 1)

        # 储存所有需要特征处理的邻接矩阵（储存为字典）
        adjacency_matrix = {'communication': adjacency_matrix_communication,
                            'safety': adjacency_matrix_safety,
                            'action': adjacency_matrix_action}

    return node_feature_matrix, adjacency_matrix
