"""
    该函数用来获得环境的图表征
    -典型图表征方法（无任何改进）
    -预期包含各个典型交通场景的图表征算法

    特征说明：
    SUMO获取车辆编号时具有自动排序功能。
    构建仿真环境时，车辆分为CAV和HV两种，编号中CAV排在HV前面。
    因此特征矩阵为[CAV1,CAV2,...,HV1,HV2,...]，可按照此规律快速获取对应车辆的特征信息
"""

import numpy as np
import traci
from sklearn.metrics.pairwise import euclidean_distances


# 将矩阵上三角赋值给下三角，减少邻接矩阵计算量
def copy_upper_to_lower(matrix):
    n = len(matrix)
    for i in range(n):
        for j in range(i + 1, n):
            matrix[j][i] = matrix[i][j]


def TTC_model(distance_x_i, vel_x_i, length_vel, t_pre):
    """
        TTC是典型模型，表示主车不采取制动情况下与前车碰撞时间
        计算该模型需要如下参数：
        -两车相对位置，相对速度
        -前车长度
    """
    if vel_x_i > 0:
        risk_value = (distance_x_i - length_vel) / vel_x_i
    else:
        risk_value = 0

    if 0 < risk_value < t_pre:
        risk_value = 1
    else:
        risk_value = 0

    return risk_value


# 构造判断轨迹是否相交的函数
def cross_product(p1, p2, q1):
    return (p2[0] - p1[0]) * (q1[1] - p1[1]) - (p2[1] - p1[1]) * (q1[0] - p1[0])


def do_segments_intersect(p1, p2, q1, q2):
    cp1 = cross_product(p1, p2, q1)
    cp2 = cross_product(p1, p2, q2)
    cp3 = cross_product(q1, q2, p1)
    cp4 = cross_product(q1, q2, p2)

    # 如果存在异号的叉积结果，则线段相交
    return (cp1 * cp2 < 0) and (cp3 * cp4 < 0)


# 根据环境更新的信息构造下一时间步的图表征
def get_feature_merging(state_next, param, action_list):
    # 获取仿真基本参数
    N = param['n_vehicles']
    num_av = param['n_av']
    num_hv = param['n_hv']  # maximum number of HDVs
    feature_length = param['Feature_length']
    observe_range = param['Observe_range']
    observe_num = param['Observe_num']
    communication_distance = param['Communication_distance']
    T_pre = 3  # 构造安全矩阵时，轨迹预测的时间步长
    Length_vel = 5  # 车身长度
    gamma = 0.95  # 动作序列折扣系数

    # 获取更新后的环境信息
    ids = state_next['ids']
    ID_AVs = state_next['ID_AVs']
    ID_HVs = state_next['ID_HVs']
    Pos = state_next['Pos']
    Pos_x = np.array(state_next['Pos_x'])
    Pos_y = np.array(state_next['Pos_y'])
    Vel_x = np.array(state_next['Vel_x'])
    Vel_y = np.array(state_next['Vel_y'])

    # 初始化节点特征矩阵，邻接矩阵
    node_feature_matrix = np.zeros([num_av + num_hv, feature_length])

    adjacency_matrix_communication = np.zeros([num_av + num_hv, num_av + num_hv])
    adjacency_matrix_safety = np.zeros([num_av + num_hv, num_av + num_hv])
    adjacency_matrix_action = np.zeros([num_av + num_hv, num_av + num_hv])

    mask = np.zeros(num_av + num_hv)

    adjacency_matrix = {'communication': adjacency_matrix_communication,
                        'safety': adjacency_matrix_safety,
                        'action': adjacency_matrix_action}

    # ------测试程序------ #
    if len(ID_AVs):
        """
            1.构造节点特征矩阵
        """
        # n_total = len(ID_AVs) + len(ID_HVs)

        # 特征数据维度调整（CAV+HV）
        Pos_x = Pos_x.reshape(-1, 1)
        Pos_y = Pos_y.reshape(-1, 1)
        Vel_x_node = Vel_x.reshape(-1, 1)
        Vel_y_node = Vel_y.reshape(-1, 1)

        # 构造特征向量
        observed_states = np.c_[Pos_x, Pos_y, Vel_x_node, Vel_y_node]

        # 构造节点特征矩阵
        node_feature_matrix[:len(ID_AVs), :] = observed_states[:len(ID_AVs), :]
        node_feature_matrix[num_av:num_av + len(ID_HVs), :] = observed_states[len(ID_AVs):, :]

        """
            2.1 构造通信矩阵
        """
        # 计算车辆之间距离
        distance_between_v = euclidean_distances(Pos)

        # 按照通信距离为邻接矩阵赋值
        adjacency_matrix_small = np.zeros_like(distance_between_v)
        adjacency_matrix_small[distance_between_v < communication_distance] = 1

        # 构造邻接矩阵
        adjacency_matrix_communication[:len(ID_AVs), :len(ID_AVs)] = adjacency_matrix_small[:len(ID_AVs), :len(ID_AVs)]

        adjacency_matrix_communication[:len(ID_AVs), num_av:num_av + len(ID_HVs)] \
            = adjacency_matrix_small[:len(ID_AVs), len(ID_AVs):]

        adjacency_matrix_communication[num_av:num_av + len(ID_HVs), :len(ID_AVs)] \
            = adjacency_matrix_small[len(ID_AVs):, :len(ID_AVs)]

        adjacency_matrix_communication[num_av:num_av + len(ID_HVs), num_av:num_av + len(ID_HVs)] \
            = adjacency_matrix_small[len(ID_AVs):, len(ID_AVs):]

        """
            2.2 构造安全矩阵（根据预测轨迹构造）
        """
        # 获取速度信息
        # Vel_x = Vel_x[:L_cav]
        # Vel_y = Vel_y[:L_cav]

        # 获取车辆总数
        n_total = len(ID_AVs) + len(ID_HVs)

        # 初始化用于储存赋值的邻接矩阵
        adjacency_matrix_safety_small = np.zeros([n_total, n_total])

        for i in range(n_total):
            for j in range(i, n_total):
                if j == i:
                    adjacency_matrix_safety_small[i][j] = 0
                elif Pos[i][1] == Pos[j][1]:  # 两辆车在同一车道
                    delta_d = Pos[j][0] - Pos[i][0]
                    delta_v = Vel_x[i] - Vel_x[j]
                    adjacency_matrix_safety_small[i][j] = TTC_model(delta_d, delta_v, Length_vel, T_pre)
                else:  # 其他情况
                    Pos_cav_i_pre = (Pos[i] +
                                     np.array([Vel_x[i] * T_pre,
                                               Vel_y[i] * T_pre]))
                    Pos_cav_j_pre = (Pos[j] +
                                     np.array([Vel_x[j] * T_pre,
                                               Vel_y[j] * T_pre]))
                    adjacency_matrix_safety_small[i][j] = do_segments_intersect(Pos[i],
                                                                                Pos_cav_i_pre,
                                                                                Pos[j],
                                                                                Pos_cav_j_pre)

        copy_upper_to_lower(adjacency_matrix_safety_small)

        # 将矩阵中元素赋值至并联式邻接矩阵中
        adjacency_matrix_safety[:len(ID_AVs), :len(ID_AVs)] = adjacency_matrix_safety_small[:len(ID_AVs), :len(ID_AVs)]

        adjacency_matrix_safety[:len(ID_AVs), num_av:num_av + len(ID_HVs)] \
            = adjacency_matrix_safety_small[:len(ID_AVs), len(ID_AVs):]

        adjacency_matrix_safety[num_av:num_av + len(ID_HVs), :len(ID_AVs)] \
            = adjacency_matrix_safety_small[len(ID_AVs):, :len(ID_AVs)]

        adjacency_matrix_safety[num_av:num_av + len(ID_HVs), num_av:num_av + len(ID_HVs)] \
            = adjacency_matrix_safety_small[len(ID_AVs):, len(ID_AVs):]

        """
            2.3 构造动作相似度矩阵
        """
        # 获取车辆总数
        n_total = len(ID_AVs) + len(ID_HVs)

        # 计算折扣系数
        length_gamma = param['time_length']
        gamma_matrix = [gamma ** i for i in range(0, length_gamma)]
        gamma_matrix.reverse()
        gamma_matrix = np.array(gamma_matrix)

        # 计算矩阵中的取值
        adjacency_matrix_small = np.zeros([n_total, n_total])
        for i in range(n_total):
            for j in range(i, n_total):
                a_norm = (action_list[i] - action_list[j]) * gamma_matrix
                adjacency_matrix_small[i][j] = np.linalg.norm(a_norm)

        copy_upper_to_lower(adjacency_matrix_small)

        # 将每一行大于该行平均值的元素设置为1
        row_averages = np.mean(adjacency_matrix_small, axis=1)
        result_matrix = np.zeros_like(adjacency_matrix_small, dtype=int)
        result_matrix[adjacency_matrix_small > row_averages[:, np.newaxis]] = 1

        # 将矩阵中元素赋值至并联式邻接矩阵中
        adjacency_matrix_action[:len(ID_AVs), :len(ID_AVs)] = result_matrix[:len(ID_AVs), :len(ID_AVs)]

        adjacency_matrix_action[:len(ID_AVs), num_av:num_av + len(ID_HVs)] \
            = result_matrix[:len(ID_AVs), len(ID_AVs):]

        adjacency_matrix_action[num_av:num_av + len(ID_HVs), :len(ID_AVs)] \
            = result_matrix[len(ID_AVs):, :len(ID_AVs)]

        adjacency_matrix_action[num_av:num_av + len(ID_HVs), num_av:num_av + len(ID_HVs)] \
            = result_matrix[len(ID_AVs):, len(ID_AVs):]

        """
            3.构造mask矩阵
        """
        mask[:len(ID_AVs)] = np.ones(len(ID_AVs))

        # 储存所有需要特征处理的邻接矩阵（储存为字典）
        adjacency_matrix = {'communication': adjacency_matrix_communication,
                            'safety': adjacency_matrix_safety,
                            'action': adjacency_matrix_action}

    return node_feature_matrix, adjacency_matrix, mask
