"""
    该函数用来获得环境的图表征
    -典型图表征方法（无任何改进）
    -预期包含各个典型交通场景的图表征算法

    特征说明：
    SUMO获取车辆编号时具有自动排序功能。
    构建仿真环境时，车辆分为CAV和HV两种，编号中CAV排在HV前面。
    因此特征矩阵为[CAV1,CAV2,...,HV1,HV2,...]，可按照此规律快速获取对应车辆的特征信息
"""
import math

import numpy as np
import traci
from sklearn.metrics.pairwise import euclidean_distances
from sklearn.preprocessing import MinMaxScaler


def calculate_cosine_similarities(A, B):
    # ------计算余弦相似性（只考虑方向）------ #
    num_vehicles = A.shape[0]

    # 如果只有一辆车，直接return
    if num_vehicles == 1:
        return np.array([[1]])

    # 将速度向量堆叠在一起形成一个三维数组
    speeds = np.dstack((A, B))

    # 计算每辆车的速度向量的范数
    norms = np.linalg.norm(speeds, axis=2)

    # 计算所有向量的点积
    dot_products = np.dot(speeds.reshape(num_vehicles, -1), speeds.reshape(num_vehicles, -1).T)

    # 计算所有向量的范数的外积
    norms_outer = np.outer(norms, norms)

    # 避免除以0的情况
    norms_outer[norms_outer == 0] = 1e-10

    # 计算余弦相似性
    similarities = dot_products / norms_outer

    # ------计算速度权重（在上面计算基础上同时考虑方向和大小）------ #
    # 计算速度差值
    norm_matrix = norms.squeeze()[:, np.newaxis]
    differences = abs(norm_matrix - norms)

    # 找到速度最大值
    max_velocity = np.maximum(norm_matrix, norms)
    # 避免除以0的情况
    max_velocity[max_velocity == 0] = 1e-10

    # 计算权重
    weights_matrix = 1 - differences / max_velocity

    # 修正相似性度量
    similarities = similarities * weights_matrix

    return similarities


# 根据环境更新的信息构造下一时间步的图表征
def get_feature_merging(state_next, param, action_list):
    # 获取仿真基本参数
    N = param['n_vehicles']
    num_av = param['n_av']
    num_hv = param['n_hv']  # maximum number of HDVs
    feature_length = param['Feature_length']
    observe_range = param['Observe_range']
    observe_num = param['Observe_num']
    communication_distance = param['Communication_distance']
    communication_loss_rate = param['com_loss']

    # 获取更新后的环境信息
    ids = state_next['ids']
    ID_AVs = state_next['ID_AVs']
    ID_HVs = state_next['ID_HVs']
    Pos = state_next['Pos']
    Pos_x = np.array(state_next['Pos_x'])
    Pos_y = np.array(state_next['Pos_y'])
    Vel_x = np.array(state_next['Vel_x'])
    Vel_y = np.array(state_next['Vel_y'])

    # 初始化节点特征矩阵，邻接矩阵
    dim_node = feature_length * (observe_num + 1)
    node_feature_matrix = np.zeros([num_av, dim_node])

    adjacency_matrix_communication = np.zeros([num_av, num_av])
    adjacency_matrix_velocity = np.zeros([num_av, num_av])

    # ------测试程序------ #
    if len(ID_AVs):
        L_cav = len(ID_AVs)
        """
            1.构造节点特征矩阵
        """
        # 位置及距离计算（这里返回的是numpy数据类型）
        distance = euclidean_distances(Pos)  # 计算环境中每两辆车之间的距离
        distance_cav = distance[:L_cav]  # 获取以CAV为参照的距离

        # distance_x = euclidean_distances(Pos_x)  # 计算环境中每两辆车之间的纵向相对位置
        # distance_y = euclidean_distances(Pos_y)  # 计算环境中每两辆车之间的横向相对位置
        # distance_x_cav = np.array(distance_x[:L_cav])  # 获取以CAV为参照的纵向相对位置
        # distance_y_cav = np.array(distance_y[:L_cav])  # 获取以CAV为参照的横向相对位置距离

        # 针对CAV构造特征向量
        for cav_i in range(0, L_cav):  # 针对每辆cav进行特征操作
            # 判断感知范围内周车数目，并获取需存储的车辆索引
            index = np.where((observe_range > distance_cav[cav_i]) & (distance_cav[cav_i] > 0))[0]  # 获取感知范围内所有车辆索引
            if len(index) > observe_num:  # 如果周车数目大于观测数目
                # 按照距离排序并选择依照距离选择观测车辆
                distance_cav_new = sorted(distance_cav[cav_i])[1: observe_num]
                # 在原数组中找到最近距离车辆的索引编号，并更新
                index_new = [np.where(distance_cav[cav_i] == elem)[0] for elem in distance_cav_new]
                index_new = np.concatenate(index_new)
            else:
                index_new = np.array(index)

            # ------考虑通讯（感知）失效，去除通讯失效的车辆------ #
            communication_loss_sense = np.random.random(len(index_new))
            communication_matrix_sense = np.ones_like(communication_loss_sense)
            communication_matrix_sense[communication_loss_sense >
                                       1 - communication_loss_rate] = 0
            # 移除通讯损失的车辆索引，不参与后续特征处理与计算
            loss_vehicles = np.where(communication_matrix_sense == 0)[0]
            index_new = np.delete(index_new, loss_vehicles)

            # 依照上述生成的新索引构造cav_i的特征向量[ego,x_i,y_i,vel_x_i,vel_y_i]，并进行拼接
            if len(index_new):
                distance_x_i = (Pos_x[index_new] - Pos_x[cav_i]).reshape(-1, 1)
                distance_y_i = (Pos_y[index_new] - Pos_y[cav_i]).reshape(-1, 1)
                vel_x_i = (Vel_x[index_new] - Vel_x[cav_i]).reshape(-1, 1)
                vel_y_i = (Vel_y[index_new] - Vel_y[cav_i]).reshape(-1, 1)
                # 构建周车特征
                feature_cav_surrounding = np.c_[distance_x_i, distance_y_i, vel_x_i, vel_y_i]
                feature_cav_surrounding = np.reshape(feature_cav_surrounding, (1, len(index_new) * feature_length))
                # 构建自车特征
                feature_cav_ego = np.c_[Pos_x[cav_i], Pos_y[cav_i], Vel_x[cav_i], Vel_y[cav_i]]
                # 特征拼接
                feature_cav_i = np.c_[feature_cav_ego, feature_cav_surrounding]
            else:
                feature_cav_i = np.c_[Pos_x[cav_i], Pos_y[cav_i], Vel_x[cav_i], Vel_y[cav_i]]

            # 构建节点特征矩阵
            if feature_cav_i.size > dim_node:
                feature_cav_i = feature_cav_i[:, :dim_node]
            node_feature_matrix[cav_i, :feature_cav_i.size] = feature_cav_i

        # 将节点特征矩阵按照cav在场景中的横坐标位置进行排序
        sorted_indices = np.argsort(-node_feature_matrix[:, 0])
        node_feature_matrix = node_feature_matrix[sorted_indices]

        """
            2.1 构造通信矩阵
        """
        # 获取cav之间的距离
        Pos_cav = Pos[:L_cav]
        distance_between_cav = euclidean_distances(Pos_cav)
        distance_between_cav = distance_between_cav + np.eye(L_cav)
        # 按照通信距离为邻接矩阵赋值
        adjacency_matrix_small = np.zeros_like(distance_between_cav)
        adjacency_matrix_small[distance_between_cav < communication_distance] = 1
        adjacency_matrix_communication[:L_cav, :L_cav] = adjacency_matrix_small

        # ------考虑通讯（网联）失效，去除通讯失效的CAV------ #
        communication_matrix_cav = np.ones(num_av)
        communication_loss_cav = np.random.random(len(ID_AVs))
        communication_matrix_cav_small = np.ones_like(communication_loss_cav)
        # 构建通信失效矩阵
        communication_matrix_cav_small[communication_loss_cav >
                                       1 - communication_loss_rate] = 0
        communication_matrix_cav[:len(ID_AVs)] = communication_matrix_cav_small

        # 考虑网联失效，邻接矩阵对应位置的cav特征归零
        adjacency_matrix_communication = \
            adjacency_matrix_communication * communication_matrix_cav \
            * communication_matrix_cav.reshape(-1, 1)

        # """
        #     2.2 构造速度相似性矩阵
        # """
        # # 定义速度相似性阈值，通过余弦相似度计算，相似度越小，说明两车速度差异性越大
        # threshold_vel = 0.5
        #
        # # 获取cav的速度向量
        # Vel_x_cav = Vel_x[:L_cav]
        # Vel_y_cav = Vel_y[:L_cav]
        #
        # # 计算相似性系数
        # sim = calculate_cosine_similarities(Vel_x_cav, Vel_y_cav)
        #
        # # 按照通信距离为邻接矩阵赋值
        # adjacency_matrix_small = np.zeros_like(sim)
        # adjacency_matrix_small[sim < threshold_vel] = 1
        # adjacency_matrix_velocity[:L_cav, :L_cav] = adjacency_matrix_small
        #
        # """
        #     2.3 构造最终邻接矩阵
        # """
        # adjacency_matrix_communication = np.multiply(adjacency_matrix_velocity,
        #                                              adjacency_matrix_communication)

    return node_feature_matrix, adjacency_matrix_communication
