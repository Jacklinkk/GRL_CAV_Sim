import torch
import torch.nn as nn


class LstmRNN(nn.Module):
    """
        Parameters：
        - input_size: feature size
        - hidden_size: number of hidden units
        - output_size: number of output
        - num_layers: layers of LSTM to stack
    """

    def __init__(self, input_size=64, hidden_size=32, output_size=8, num_layers=1,
                 kernel_size=(3, 10), stride=1, dropout=0, input_len=10, output_len=1):
        super().__init__()
        self.hidden_dim = hidden_size
        self.input_dim = input_len
        self.lstm = nn.LSTM(input_size, hidden_size)  # utilize the LSTM model in torch.nn
        # self.lstm = nn.RNN(input_size, hidden_size, num_layers)
        self.linear1 = nn.Linear(hidden_size, output_size)
        assert len(kernel_size) == 2
        assert kernel_size[0] % 2 == 1
        padding = ((kernel_size[0] - 1) // 2, 0)
        self.tcn = nn.Sequential(
            nn.BatchNorm2d(input_len),
            nn.PReLU(),
            nn.Conv2d(
                input_len,
                output_len,
                (kernel_size[0], 1),
                (stride, 1),
                padding,
            ),
            nn.BatchNorm2d(output_len),
            nn.Dropout(dropout, inplace=True),
        )
        self.action_layer = nn.Linear(hidden_size, input_size)
        self.hidden = self.init_hidden()

    def init_hidden(self):
        return (torch.zeros(1, self.input_dim, self.hidden_dim).cuda(),
                torch.zeros(1, self.input_dim, self.hidden_dim).cuda())

    def forward(self, _x):
        if isinstance(self.hidden, tuple):
            hidden_tensor = (self.hidden[0].detach(), self.hidden[1].detach())
        x, self.hidden = self.lstm(_x, hidden_tensor)  # _x is input, size (seq_len, batch, input_size)
        # s, b, h = x.shape  # x is output, size (seq_len, batch, hidden_size)
        # x = x.view(s * b, h)
        # x = self.linear1(x)
        # x = x.view(s, b, -1)
        # print(x.shape)
        x = x.permute(1, 0, 2).unsqueeze(0)
        # print(x.shape)
        x = self.tcn(x)
        _, seq_len, node_num, hidden_size = x.shape
        x = x.view(node_num, hidden_size)
        x = self.action_layer(x)
        return x


if __name__ == '__main__':
    input_tensor = torch.randn(37, 10, 64).cuda()
    # input_tensor = input_tensor.unsqueeze(1)
    print(input_tensor.shape)
    model = LstmRNN(64, 32, 1).cuda()
    output = model(input_tensor)
    print(output.shape)
    torch.cuda.empty_cache()
