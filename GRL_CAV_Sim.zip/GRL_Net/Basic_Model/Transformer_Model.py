import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

import time
import math

"""
    模型相关参数说明：
    类比到 multi-agent decision-making 问题：
    batch_size对应时间序列的长度
    seq_len对应智能体的数量
    d_model对应智能体的特征长度
"""


# 定义typical位置编码方法
def Typical_PE(seq_length, d_model):
    """
        生成位置编码矩阵。该矩阵的每一行代表输入序列中的一个位置。
        每个位置的编码包括正弦和余弦函数，以捕捉位置之间的相对位置信息。
    """
    positional_encoding = torch.zeros(seq_length, d_model)
    position = torch.arange(0, seq_length, dtype=torch.float).unsqueeze(1)
    div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))

    positional_encoding[:, 0::2] = torch.sin(position * div_term)
    positional_encoding[:, 1::2] = torch.cos(position * div_term)

    positional_encoding = positional_encoding.unsqueeze(0)  # shape: (1, seq_length, d_model)
    return positional_encoding


# 定义旋转位置编码方法
# 旋转矩阵构造函数
def precompute_freqs_cis(seq_len: int, dim: int, theta: float = 10000.0):
    # 计算词向量元素两两分组之后，每组元素对应的旋转角度\theta_i
    freqs = 1.0 / (theta ** (torch.arange(0, dim, 2)[: (dim // 2)].float() / dim))
    # 生成 token 序列索引 t = [0, 1,..., seq_len-1]
    t = torch.arange(seq_len, device=freqs.device)
    # freqs.shape = [seq_len, dim // 2]
    freqs = torch.outer(t, freqs).float()  # 计算m * \theta

    # 计算结果是个复数向量
    # 假设 freqs = [x, y]
    # 则 freqs_cis = [cos(x) + sin(x)i, cos(y) + sin(y)i]
    freqs_cis = torch.polar(torch.ones_like(freqs), freqs)
    return freqs_cis


# 旋转位置编码计算（针对q和k执行）
def apply_rotary_emb(xq: torch.Tensor,
                     xk: torch.Tensor,
                     freqs_cis: torch.Tensor):
    # xq.shape = [batch_size, seq_len, dim]
    # xq_.shape = [batch_size, seq_len, dim // 2, 2]
    xq_ = xq.float().reshape(*xq.shape[:-1], -1, 2)
    xk_ = xk.float().reshape(*xk.shape[:-1], -1, 2)

    # 转为复数域
    xq_ = torch.view_as_complex(xq_)
    xk_ = torch.view_as_complex(xk_)

    # 应用旋转操作，然后将结果转回实数域
    # xq_out.shape = [batch_size, seq_len, dim]
    xq_out = torch.view_as_real(xq_ * freqs_cis).flatten(2)
    xk_out = torch.view_as_real(xk_ * freqs_cis).flatten(2)
    return xq_out.type_as(xq), xk_out.type_as(xk)


# 定义前馈神经网络层
class FeedForward(nn.Module):
    def __init__(self,
                 d_model,
                 dim_feedforward,
                 dropout):
        super(FeedForward, self).__init__()
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.linear2 = nn.Linear(dim_feedforward, d_model)
        self.dropout = nn.Dropout(dropout, inplace=True)

        # GPU configuration
        if torch.cuda.is_available():
            GPU_num = torch.cuda.current_device()
            self.device = torch.device("cuda:{}".format(GPU_num))
        else:
            self.device = "cpu"

        self.to(self.device)

    def forward(self, x):
        return self.dropout(self.linear2(F.relu(self.linear1(x))))


# 定义掩模多头注意力机制
class MaskedMultiHeadAttention(nn.Module):
    def __init__(self,
                 d_model,
                 n_head,
                 rotary):
        super(MaskedMultiHeadAttention, self).__init__()
        self.d_model = d_model
        self.n_head = n_head
        self.d_k = d_model // n_head
        self.is_rotary = rotary

        assert d_model % n_head == 0, "d_model must be divisible by n_head"

        self.query = nn.Linear(d_model, d_model)
        self.key = nn.Linear(d_model, d_model)
        self.value = nn.Linear(d_model, d_model)
        self.out = nn.Linear(d_model, d_model)

        # GPU configuration
        if torch.cuda.is_available():
            GPU_num = torch.cuda.current_device()
            self.device = torch.device("cuda:{}".format(GPU_num))
        else:
            self.device = "cpu"

        self.to(self.device)

    def forward(self, q, k, v, mask=True):
        batch_size, seq_len, dim_feature = q.size()

        v = self.value(v).view(batch_size, -1, self.n_head, self.d_k).transpose(1, 2)

        # 执行旋转位置编码，并计算对应的注意力矩阵（q和k）
        if self.is_rotary:
            q = self.query(q)
            k = self.key(k)
            q, k = apply_rotary_emb(q, k, precompute_freqs_cis(seq_len, dim_feature).to(self.device))
            q = q.view(batch_size, -1, self.n_head, self.d_k).transpose(1, 2)
            k = k.view(batch_size, -1, self.n_head, self.d_k).transpose(1, 2)
        else:
            q = self.query(q).view(batch_size, -1, self.n_head, self.d_k).transpose(1, 2)
            k = self.key(k).view(batch_size, -1, self.n_head, self.d_k).transpose(1, 2)

        # Scaled dot-product attention
        scores = torch.matmul(q, k.transpose(-2, -1)) / np.sqrt(self.d_k)

        if mask:
            attn_mask = torch.triu(torch.ones(seq_len, seq_len), diagonal=1).bool().to(self.device)
            scores = scores.masked_fill(attn_mask, -1e9)
        # if mask is not None:
        #     # Apply the mask by setting very large negative values to masked positions
        #     scores = scores.masked_fill(mask == 0, -1e9)

        attention = F.softmax(scores, dim=-1)
        x = torch.matmul(attention, v)

        # Concatenate heads and put through final linear layer
        x = x.transpose(1, 2).contiguous().view(batch_size, -1, self.d_model)
        return self.out(x)


# 定义transformer编码器层
class TransformerEncoderLayer(nn.Module):
    def __init__(self,
                 d_model,
                 n_head,
                 dim_feedforward,
                 dropout,
                 rotary):
        super(TransformerEncoderLayer, self).__init__()
        self.self_attn = MaskedMultiHeadAttention(d_model, n_head, rotary)
        self.feed_forward = FeedForward(d_model, dim_feedforward, dropout)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)

        # GPU configuration
        if torch.cuda.is_available():
            GPU_num = torch.cuda.current_device()
            self.device = torch.device("cuda:{}".format(GPU_num))
        else:
            self.device = "cpu"

        self.to(self.device)

    def forward(self, x):
        # Self-attention with residual connection and layer norm
        attn_output = self.self_attn(x, x, x)
        x = self.norm1(x + attn_output)

        # Feedforward with residual connection and layer norm
        ff_output = self.feed_forward(x)
        x = self.norm2(x + ff_output)

        return x


# 定义完整的transformer编码器
class TransformerEncoder(nn.Module):
    def __init__(self,
                 d_model,
                 n_head,
                 num_encoder_layers,
                 dim_feedforward,
                 dropout=0,
                 rotary=False):
        super(TransformerEncoder, self).__init__()
        self.layers = nn.ModuleList(
            [TransformerEncoderLayer(d_model, n_head, dim_feedforward, dropout, rotary) for _ in
             range(num_encoder_layers)])

        # GPU configuration
        if torch.cuda.is_available():
            GPU_num = torch.cuda.current_device()
            self.device = torch.device("cuda:{}".format(GPU_num))
        else:
            self.device = "cpu"

        self.to(self.device)

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x


if __name__ == '__main__':
    # RoPE测试
    # rotary_matrix = precompute_freqs_cis(3, 64)
    # q = torch.randn(1, 3, 64)
    # k = torch.randn(1, 3, 64)
    # q, k = apply_rotary_emb(q, k, rotary_matrix)

    # transformer模型测试
    d_model = 128
    src = torch.randn(5, 10, 128).cuda()
    # input_tensor = input_tensor.unsqueeze(1)
    print(src.shape)
    model = TransformerEncoder(d_model=128,
                               n_head=1,
                               num_encoder_layers=2,
                               dim_feedforward=32,
                               dropout=0,
                               rotary=False)
    time1 = time.time()
    output = model(src)
    time2 = time.time()
    print(output.shape)

    # print(Typical_PE(10, 64))

    torch.cuda.empty_cache()
