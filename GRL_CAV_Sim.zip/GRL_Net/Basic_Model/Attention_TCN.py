import torch
import torch.nn as nn
import torch.nn.functional as F


class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc1 = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

        # ------GPU设置------ #
        if torch.cuda.is_available():
            GPU_num = torch.cuda.current_device()
            self.device = torch.device("cuda:{}".format(GPU_num))
        else:
            self.device = "cpu"

        self.to(self.device)

    def forward(self, x):
        avg = self.avg_pool(x)
        avg_out = self.fc2(self.relu1(self.fc1(avg)))
        max = self.max_pool(x)
        max_out = self.fc2(self.relu1(self.fc1(max)))
        output = self.sigmoid(avg_out + max_out)
        # 元素-wise相乘进行特征增强
        output = output.expand_as(x)
        output = x * output

        return output


class TCN(nn.Module):
    """
        Parameters：
        - input_size: feature size
        - hidden_size: number of hidden units
        - output_size: number of output
        - num_layers: layers of LSTM to stack
    """

    def __init__(self,
                 kernel_size=(3, 1),
                 dilation=(2, 1),
                 dropout=0,
                 input_time_length=10,
                 output_time_length=1):
        super(TCN, self).__init__()
        self.input_time_length = input_time_length
        self.output_time_length = output_time_length

        # ------定义TCN网络------ #
        assert len(kernel_size) == 2
        assert kernel_size[0] % 2 == 1
        self.padding = (dilation[0] * (kernel_size[0] - 1) // 2, 0)

        self.bn1 = nn.BatchNorm2d(self.input_time_length)
        self.activation = nn.PReLU()
        self.conv = nn.Conv2d(in_channels=input_time_length,
                              out_channels=output_time_length,
                              kernel_size=kernel_size,
                              stride=(1, 1),
                              dilation=dilation,
                              padding=self.padding)
        self.bn2 = nn.BatchNorm2d(self.output_time_length)
        self.dropout = nn.Dropout(dropout, inplace=True)

        # 初始化残差连接
        if self.input_time_length != self.output_time_length:
            self.ResNet = nn.Sequential(
                nn.Conv2d(self.input_time_length,
                          self.output_time_length,
                          kernel_size=(1, 1),
                          stride=(1, 1)),
                nn.BatchNorm2d(self.output_time_length),
            )
        else:
            self.ResNet = None

        # ------GPU设置------ #
        if torch.cuda.is_available():
            GPU_num = torch.cuda.current_device()
            self.device = torch.device("cuda:{}".format(GPU_num))
        else:
            self.device = "cpu"

        self.to(self.device)

    def forward(self, x):
        residual = x

        out = self.bn1(x)
        out = self.activation(out)
        out = self.conv(out)
        out = self.bn2(out)
        out = self.dropout(out)

        if self.ResNet is not None:
            residual = self.ResNet(residual)

        out += residual
        out = F.relu(out)

        return out


class Attention_TCN(nn.Module):
    """
        Parameters：
        - input_size: feature size
        - hidden_size: number of hidden units
        - output_size: number of output
        - num_layers: layers of LSTM to stack
    """

    def __init__(self,
                 input_seq_length,
                 output_seq_length,
                 kernel_size=(3, 1),
                 dilation=(2, 1),
                 dropout=0,
                 ratio=1,
                 ):
        super(Attention_TCN, self).__init__()

        # 定义channel attention层
        self.attention = ChannelAttention(input_seq_length, ratio)

        # 定义TCN层
        self.tcn_layer = TCN(input_time_length=input_seq_length,  # 输入时间序列长度
                             output_time_length=output_seq_length,  # 输出时间序列长度
                             kernel_size=kernel_size,  # 卷积核
                             dilation=dilation,  # 膨胀卷积
                             dropout=dropout,  # dropout比例
                             )

        # ------GPU设置------ #
        if torch.cuda.is_available():
            GPU_num = torch.cuda.current_device()
            self.device = torch.device("cuda:{}".format(GPU_num))
        else:
            self.device = "cpu"

        self.to(self.device)

    def forward(self, x):
        # 输入至通道注意力层
        x_out = self.attention(x)

        # 输入至TCN层
        x_out = self.tcn_layer(x_out)

        return x_out
