import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from torch_geometric.utils import dense_to_sparse


def datatype_transmission(states, device):
    """
        1.This function is used to convert observations in the environment to the
        float32 Tensor data type that pytorch can accept.
        2.Pay attention: Depending on the characteristics of the data structure of
        the observation, the function needs to be changed accordingly.
    """
    features = torch.as_tensor(states[0], dtype=torch.float32, device=device)
    adjacency = torch.as_tensor(states[1], dtype=torch.float32, device=device)
    # mask = torch.as_tensor(states[2], dtype=torch.float32, device=device)

    return features, adjacency


# ------Graph Model------ #
class Graph_Model(nn.Module):
    """
        1.N is the number of vehicles
        2.F is the feature length of each vehicle
        3.A is the number of selectable actions
    """

    def __init__(self, N, F, A):
        super(Graph_Model, self).__init__()
        self.num_agents = N
        self.num_outputs = A

        # Encoder
        self.encoder_1 = nn.Linear(F, 32)
        self.encoder_2 = nn.Linear(32, 32)

        # GNN
        self.GraphConv = GCNConv(32, 32)
        self.GraphConv_Dense = nn.Linear(32, 32)

        # Policy network
        self.policy_1 = nn.Linear(64, 32)
        self.policy_2 = nn.Linear(32, 32)
        self.policy_output = nn.Linear(32, A)

        # GPU configuration
        if torch.cuda.is_available():
            GPU_num = torch.cuda.current_device()
            self.device = torch.device("cuda:{}".format(GPU_num))
        else:
            self.device = "cpu"

        self.to(self.device)

    def forward(self, observation):
        """
            1.The data type here is numpy.ndarray, which needs to be converted to a
            Tensor data type.
            2.Observation is the state observation matrix, including X_in, A_in_Dense
            and RL_indice.
            3.X_in is the node feature matrix, A_in_Dense is the dense adjacency matrix
            (NxN) (original input)
            4.A_in_Sparse is the sparse adjacency matrix COO (2xnum), RL_indice is the
            reinforcement learning index of controlled vehicles.
        """

        # X_in, A_in_Dense, RL_indice = datatype_transmission(observation, self.device)

        X_in, A_in_Dense = datatype_transmission(observation, self.device)

        # Encoder
        X = self.encoder_1(X_in)
        X = F.relu(X)
        X = self.encoder_2(X)
        X = F.relu(X)

        # GCN
        A_in_Sparse, _ = dense_to_sparse(A_in_Dense)
        X_graph = self.GraphConv(X, A_in_Sparse)
        X_graph = F.relu(X_graph)
        X_graph = self.GraphConv_Dense(X_graph)
        X_graph = F.relu(X_graph)

        # Feature concatenation
        F_concat = torch.cat((X_graph, X), 1)

        # Policy
        X_policy = self.policy_1(F_concat)
        X_policy = F.relu(X_policy)
        X_policy = self.policy_2(X_policy)
        X_policy = F.relu(X_policy)
        X_policy = self.policy_output(X_policy)

        # Mask
        # mask = torch.reshape(RL_indice, (self.num_agents, 1))

        # Output calculation
        output = X_policy

        return output


# ------Graph Model Interaction------ #
class Graph_Model_Interaction(nn.Module):
    """
        1.N is the number of vehicles
        2.F is the feature length of each vehicle
        3.A is the number of selectable actions
    """

    def __init__(self, N, F, A):
        super(Graph_Model_Interaction, self).__init__()
        self.num_agents = N
        self.num_outputs = A

        # Encoder
        self.encoder_1 = nn.Linear(F, 32)
        self.encoder_2 = nn.Linear(32, 32)

        # GNN（三个网络分别处理三个邻接矩阵）
        self.GraphConv_c = GCNConv(32, 32)
        self.GraphConv_v = GCNConv(32, 32)
        self.GraphConv_a = GCNConv(32, 32)
        self.GraphConv_Dense_c = nn.Linear(32, 32)
        self.GraphConv_Dense_v = nn.Linear(32, 32)
        self.GraphConv_Dense_a = nn.Linear(32, 32)

        # Policy network
        self.policy_1 = nn.Linear(64, 32)
        self.policy_2 = nn.Linear(32, 32)
        self.policy_output = nn.Linear(32, A)

        # GPU configuration
        if torch.cuda.is_available():
            GPU_num = torch.cuda.current_device()
            self.device = torch.device("cuda:{}".format(GPU_num))
        else:
            self.device = "cpu"

        self.to(self.device)

    def forward(self, observation):
        """
            1.The data type here is numpy.ndarray, which needs to be converted to a
            Tensor data type.
            2.Observation is the state observation matrix, including X_in, A_in_Dense
            and RL_indice.
            3.X_in is the node feature matrix, A_in_Dense is the dense adjacency matrix
            (NxN) (original input)
            4.A_in_Sparse is the sparse adjacency matrix COO (2xnum), RL_indice is the
            reinforcement learning index of controlled vehicles.
        """

        # X_in, A_in_Dense, RL_indice = datatype_transmission(observation, self.device)

        X_in = torch.as_tensor(observation[0],
                               dtype=torch.float32, device=self.device)
        # 获取邻接矩阵
        A_c_dense = torch.as_tensor(observation[1]['communication'],
                                    dtype=torch.float32, device=self.device)
        A_v_dense = torch.as_tensor(observation[1]['safety'],
                                    dtype=torch.float32, device=self.device)
        A_a_dense = torch.as_tensor(observation[1]['action'],
                                    dtype=torch.float32, device=self.device)

        # Encoder
        X = self.encoder_1(X_in)
        X = F.relu(X)
        X = self.encoder_2(X)
        X = F.relu(X)

        # 通过GCN分别处理三个邻接矩阵
        A_in_Sparse_c, _ = dense_to_sparse(A_c_dense)
        X_graph_c = self.GraphConv_c(X, A_in_Sparse_c)
        X_graph_c = F.relu(X_graph_c)
        X_graph_c = self.GraphConv_Dense_c(X_graph_c)
        X_graph_c = F.relu(X_graph_c)

        A_in_Sparse_v, _ = dense_to_sparse(A_v_dense)
        X_graph_v = self.GraphConv_v(X, A_in_Sparse_v)
        X_graph_v = F.relu(X_graph_v)
        X_graph_v = self.GraphConv_Dense_c(X_graph_v)
        X_graph_v = F.relu(X_graph_v)

        A_in_Sparse_a, _ = dense_to_sparse(A_a_dense)
        X_graph_a = self.GraphConv_a(X, A_in_Sparse_a)
        X_graph_a = F.relu(X_graph_a)
        X_graph_a = self.GraphConv_Dense_c(X_graph_a)
        X_graph_a = F.relu(X_graph_a)

        # 特征合并
        X_graph = X_graph_c + X_graph_v + X_graph_a

        # Feature concatenation
        F_concat = torch.cat((X_graph, X), 1)

        # Policy
        X_policy = self.policy_1(F_concat)
        X_policy = F.relu(X_policy)
        X_policy = self.policy_2(X_policy)
        X_policy = F.relu(X_policy)
        X_policy = self.policy_output(X_policy)

        # Mask
        # mask = torch.reshape(RL_indice, (self.num_agents, 1))

        # Output calculation
        output = X_policy

        return output


# ------Graph Model Invariance------ #
class Graph_Model_Invariance(nn.Module):
    # F_in为每辆hv的特征向量长度，F_out为预编码后的输出特征长度
    def __init__(self, N, F_in, F_out, A):
        super(Graph_Model_Invariance, self).__init__()
        self.num_agents = N
        self.num_outputs = A
        self.F_in = F_in
        self.F_out = F_out

        # Encoder_surrounding（编码周车信息）
        self.encoder_s_1 = nn.Linear(F_in, 16)
        self.encoder_s_2 = nn.Linear(16, F_out)

        # Encoder_cav
        self.encoder_cav_1 = nn.Linear(F_out + F_in, 32)
        self.encoder_cav_2 = nn.Linear(32, 32)

        # GNN
        self.GraphConv = GCNConv(32, 32)
        self.GraphConv_Dense = nn.Linear(32, 32)

        # Policy network
        self.policy_1 = nn.Linear(64, 32)
        self.policy_2 = nn.Linear(32, 32)
        self.policy_output = nn.Linear(32, A)

        # GPU configuration
        if torch.cuda.is_available():
            GPU_num = torch.cuda.current_device()
            self.device = torch.device("cuda:{}".format(GPU_num))
        else:
            self.device = "cpu"

        self.to(self.device)

    def forward(self, observation):
        """
            1.The data type here is numpy.ndarray, which needs to be converted to a
            Tensor data type.
            2.Observation is the state observation matrix, including X_in, A_in_Dense
            and RL_indice.
            3.X_in is the node feature matrix, A_in_Dense is the dense adjacency matrix
            (NxN) (original input)
            4.A_in_Sparse is the sparse adjacency matrix COO (2xnum), RL_indice is the
            reinforcement learning index of controlled vehicles.
        """

        # Encoder_surrounding
        X_in = np.zeros([self.num_agents, self.F_in + self.F_out])
        X_in = torch.as_tensor(X_in, dtype=torch.float32, device=self.device)

        for cav_num, feature_cav_i in enumerate(observation[0]):
            # 获取cav_i以及cav_i的周车特征（数组第一项是cav的特征）
            feature_cav_i_ego = torch.as_tensor(feature_cav_i[0],
                                                dtype=torch.float32,
                                                device=self.device)
            # cav附近存在可观测到的周车
            if len(feature_cav_i) > 1:
                feature_cav_i_surrounding = feature_cav_i[1:]

                # 构建储存hv编码的矩阵
                hv_i_matrix = []

                # 通过循环依次对周车进行编码
                for hv_i in feature_cav_i_surrounding:
                    hv_i = torch.as_tensor(hv_i, dtype=torch.float32, device=self.device)
                    # 进行周车编码
                    hv_i_encoded = self.encoder_s_1(hv_i)
                    hv_i_encoded = self.encoder_s_2(hv_i_encoded)
                    hv_i_encoded = F.relu(hv_i_encoded)
                    hv_i_matrix.append(hv_i_encoded)

                # 将编码后的周车特征矩阵转换为Tensor
                hv_i_matrix = torch.stack(hv_i_matrix)

                # 如果进行了风险评估，加权求值
                if len(observation) == 3:
                    risk_value = torch.as_tensor(observation[2][cav_num], dtype=torch.float32,
                                                 device=self.device).reshape(-1, 1)
                    risk_value = F.softmax(abs(risk_value), dim=0)
                    hv_i_matrix = hv_i_matrix * risk_value
                    hv_i_matrix = torch.sum(hv_i_matrix, dim=0)
                else:  # 未进行风险评估，直接求均值
                    hv_i_matrix = torch.mean(hv_i_matrix, dim=0)

                # 构建cav_i的特征向量
                cav_i = torch.cat((feature_cav_i_ego, hv_i_matrix), 0)
            # 如果不存在可观测的周车，只存在cav自身特征
            else:
                cav_i = feature_cav_i_ego

            # 将特征向量储存至X_in中
            X_in[cav_num, :len(cav_i)] = cav_i

        # Encoder
        X = self.encoder_cav_1(X_in)
        X = F.relu(X)
        X = self.encoder_cav_2(X)
        X = F.relu(X)

        # GCN
        A_in_Dense = torch.as_tensor(observation[1],
                                     dtype=torch.float32,
                                     device=self.device)

        A_in_Sparse, _ = dense_to_sparse(A_in_Dense)
        X_graph = self.GraphConv(X, A_in_Sparse)
        X_graph = F.relu(X_graph)
        X_graph = self.GraphConv_Dense(X_graph)
        X_graph = F.relu(X_graph)

        # Feature concatenation
        F_concat = torch.cat((X_graph, X), 1)

        # Policy
        X_policy = self.policy_1(F_concat)
        X_policy = F.relu(X_policy)
        X_policy = self.policy_2(X_policy)
        X_policy = F.relu(X_policy)
        X_policy = self.policy_output(X_policy)

        # Mask
        # mask = torch.reshape(RL_indice, (self.num_agents, 1))

        # Output calculation
        output = X_policy

        return output


# ------Graph Model Invariance Interaction------ #
class Graph_Model_Invariance_Interaction(nn.Module):
    # F_in为每辆hv的特征向量长度，F_out为预编码后的输出特征长度
    def __init__(self, N, F_in, F_out, A):
        super(Graph_Model_Invariance_Interaction, self).__init__()
        self.num_agents = N
        self.num_outputs = A
        self.F_in = F_in
        self.F_out = F_out

        # Encoder_surrounding（编码周车信息）
        self.encoder_s_1 = nn.Linear(F_in, 16)
        self.encoder_s_2 = nn.Linear(16, F_out)

        # Encoder_cav
        self.encoder_cav_1 = nn.Linear(F_out + F_in, 32)
        self.encoder_cav_2 = nn.Linear(32, 32)

        # GNN（三个网络分别处理三个邻接矩阵）
        self.GraphConv_c = GCNConv(32, 32)
        self.GraphConv_v = GCNConv(32, 32)
        self.GraphConv_a = GCNConv(32, 32)
        self.GraphConv_Dense_c = nn.Linear(32, 32)
        self.GraphConv_Dense_v = nn.Linear(32, 32)
        self.GraphConv_Dense_a = nn.Linear(32, 32)

        # Policy network
        self.policy_1 = nn.Linear(64, 32)
        self.policy_2 = nn.Linear(32, 32)
        self.policy_output = nn.Linear(32, A)

        # GPU configuration
        if torch.cuda.is_available():
            GPU_num = torch.cuda.current_device()
            self.device = torch.device("cuda:{}".format(GPU_num))
        else:
            self.device = "cpu"

        self.to(self.device)

    def forward(self, observation):
        """
            1.The data type here is numpy.ndarray, which needs to be converted to a
            Tensor data type.
            2.Observation is the state observation matrix, including X_in, A_in_Dense
            and RL_indice.
            3.X_in is the node feature matrix, A_in_Dense is the dense adjacency matrix
            (NxN) (original input)
            4.A_in_Sparse is the sparse adjacency matrix COO (2xnum), RL_indice is the
            reinforcement learning index of controlled vehicles.
        """

        # Encoder_surrounding
        X_in = np.zeros([self.num_agents, self.F_in + self.F_out])
        X_in = torch.as_tensor(X_in, dtype=torch.float32, device=self.device)

        # 获取邻接矩阵
        A_c_dense = torch.as_tensor(observation[1]['communication'],
                                    dtype=torch.float32, device=self.device)
        A_v_dense = torch.as_tensor(observation[1]['safety'],
                                    dtype=torch.float32, device=self.device)
        A_a_dense = torch.as_tensor(observation[1]['action'],
                                    dtype=torch.float32, device=self.device)

        for cav_num, feature_cav_i in enumerate(observation[0]):
            # 获取cav_i以及cav_i的周车特征（数组第一项是cav的特征）
            feature_cav_i_ego = torch.as_tensor(feature_cav_i[0],
                                                dtype=torch.float32,
                                                device=self.device)
            # cav附近存在可观测到的周车
            if len(feature_cav_i) > 1:
                feature_cav_i_surrounding = feature_cav_i[1:]

                # 构建储存hv编码的矩阵
                hv_i_matrix = []

                # 通过循环依次对周车进行编码
                for hv_i in feature_cav_i_surrounding:
                    hv_i = torch.as_tensor(hv_i, dtype=torch.float32, device=self.device)
                    # 进行周车编码
                    hv_i_encoded = self.encoder_s_1(hv_i)
                    hv_i_encoded = self.encoder_s_2(hv_i_encoded)
                    hv_i_encoded = F.relu(hv_i_encoded)
                    hv_i_matrix.append(hv_i_encoded)

                # 将编码后的周车特征矩阵转换为Tensor
                hv_i_matrix = torch.stack(hv_i_matrix)

                # 如果进行了风险评估，加权求值
                if len(observation) == 3:
                    risk_value = torch.as_tensor(observation[2][cav_num], dtype=torch.float32,
                                                 device=self.device).reshape(-1, 1)
                    risk_value = F.softmax(abs(risk_value), dim=0)
                    hv_i_matrix = hv_i_matrix * risk_value
                    hv_i_matrix = torch.sum(hv_i_matrix, dim=0)
                else:  # 未进行风险评估，直接求均值
                    hv_i_matrix = torch.mean(hv_i_matrix, dim=0)

                # 构建cav_i的特征向量
                cav_i = torch.cat((feature_cav_i_ego, hv_i_matrix), 0)
            # 如果不存在可观测的周车，只存在cav自身特征
            else:
                cav_i = feature_cav_i_ego

            # 将特征向量储存至X_in中
            X_in[cav_num, :len(cav_i)] = cav_i

        # Encoder
        X = self.encoder_cav_1(X_in)
        X = F.relu(X)
        X = self.encoder_cav_2(X)
        X = F.relu(X)

        # 通过GCN分别处理三个邻接矩阵
        A_in_Sparse_c, _ = dense_to_sparse(A_c_dense)
        X_graph_c = self.GraphConv_c(X, A_in_Sparse_c)
        X_graph_c = F.relu(X_graph_c)
        X_graph_c = self.GraphConv_Dense_c(X_graph_c)
        X_graph_c = F.relu(X_graph_c)

        A_in_Sparse_v, _ = dense_to_sparse(A_v_dense)
        X_graph_v = self.GraphConv_v(X, A_in_Sparse_v)
        X_graph_v = F.relu(X_graph_v)
        X_graph_v = self.GraphConv_Dense_c(X_graph_v)
        X_graph_v = F.relu(X_graph_v)

        A_in_Sparse_a, _ = dense_to_sparse(A_a_dense)
        X_graph_a = self.GraphConv_a(X, A_in_Sparse_a)
        X_graph_a = F.relu(X_graph_a)
        X_graph_a = self.GraphConv_Dense_c(X_graph_a)
        X_graph_a = F.relu(X_graph_a)

        # 特征合并
        X_graph = X_graph_c + X_graph_v + X_graph_a

        # Feature concatenation
        F_concat = torch.cat((X_graph, X), 1)

        # Policy
        X_policy = self.policy_1(F_concat)
        X_policy = F.relu(X_policy)
        X_policy = self.policy_2(X_policy)
        X_policy = F.relu(X_policy)
        X_policy = self.policy_output(X_policy)

        # Mask
        # mask = torch.reshape(RL_indice, (self.num_agents, 1))

        # Output calculation
        output = X_policy

        return output


# ------NonGraph Model------ #
class NonGraph_Model(nn.Module):
    """
        1.N is the number of vehicles
        2.F is the feature length of each vehicle
        3.A is the number of selectable actions
    """

    def __init__(self, N, F, A):
        super(NonGraph_Model, self).__init__()
        self.num_agents = N
        self.num_outputs = A

        # Policy network
        self.policy_1 = nn.Linear(F, 32)
        self.policy_2 = nn.Linear(32, 32)
        self.policy_output = nn.Linear(32, A)

        # GPU configuration
        if torch.cuda.is_available():
            GPU_num = torch.cuda.current_device()
            self.device = torch.device("cuda:{}".format(GPU_num))
        else:
            self.device = "cpu"

        self.to(self.device)

    def forward(self, observation):
        """
            1.The data type here is numpy.ndarray, which needs to be converted to a
            Tensor data type.
            2.Observation is the state observation matrix, including X_in, and RL_indice.
            3.X_in is the node feature matrix, RL_indice is the reinforcement learning
            index of controlled vehicles.
        """

        X_in, _ = datatype_transmission(observation, self.device)

        # Policy
        X_policy = self.policy_1(X_in)
        X_policy = F.relu(X_policy)
        X_policy = self.policy_2(X_policy)
        X_policy = F.relu(X_policy)
        X_policy = self.policy_output(X_policy)

        # Policy output
        # mask = torch.reshape(RL_indice, (self.num_agents, 1))
        output = X_policy

        return output
