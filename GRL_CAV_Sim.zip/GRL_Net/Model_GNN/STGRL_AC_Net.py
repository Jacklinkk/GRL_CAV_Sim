import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from torch_geometric.utils import dense_to_sparse
from GRL_Net.Basic_Model import Data_seq, Attention_TCN


def datatype_transmission(states, device):
    """
        1.This function is used to convert observations in the environment to the
        float32 Tensor data type that pytorch can accept.
        2.Pay attention: Depending on the characteristics of the data structure of
        the observation, the function needs to be changed accordingly.
    """
    features = torch.as_tensor(states[0], dtype=torch.float32, device=device)
    adjacency = torch.as_tensor(states[1], dtype=torch.float32, device=device)
    # mask = torch.as_tensor(states[2], dtype=torch.float32, device=device)

    return features, adjacency


# ------Graph Model------ #
class Graph_Model(nn.Module):
    """
        1.N is the number of vehicles
        2.F is the feature length of each vehicle
        3.A is the number of selectable actions
    """

    def __init__(self, N, F, A, time_obs):
        super(Graph_Model, self).__init__()
        self.num_agents = N
        self.num_outputs = A
        self.time_obs = time_obs

        # 时序网络
        # 定义数据队列储存时序特征
        self.feature_queue = Data_seq.Data_seq()
        # 定义TCN
        self.temporal_net = Attention_TCN.TCN(kernel_size=(3, 1),  # 卷积核
                                              dilation=(2, 1),  # 膨胀卷积
                                              dropout=0,  # dropout比例
                                              input_time_length=self.time_obs,  # 输入时间序列长度
                                              output_time_length=1,  # 输出时间序列长度
                                              )

        # Encoder
        self.encoder_1 = nn.Linear(F, 32)
        self.encoder_2 = nn.Linear(32, 32)

        # GNN（三个网络分别处理三个邻接矩阵）
        self.GraphConv_com = GCNConv(32, 32)
        self.GraphConv_safe = GCNConv(32, 32)
        self.GraphConv_action = GCNConv(32, 32)
        self.GraphConv_Dense_com = nn.Linear(32, 32)
        self.GraphConv_Dense_safe = nn.Linear(32, 32)
        self.GraphConv_Dense_action = nn.Linear(32, 32)

        # Policy network
        self.policy_1 = nn.Linear(64, 32)
        self.policy_2 = nn.Linear(32, 32)

        # AC network
        self.pi = nn.Linear(32, A)
        self.value = nn.Linear(32, 1)

        # GPU configuration
        if torch.cuda.is_available():
            GPU_num = torch.cuda.current_device()
            self.device = torch.device("cuda:{}".format(GPU_num))
        else:
            self.device = "cpu"

        self.to(self.device)

    def forward(self, observation):
        """
            1.The data type here is numpy.ndarray, which needs to be converted to a
            Tensor data type.
            2.Observation is the state observation matrix, including X_in, A_in_Dense
            and RL_indice.
            3.X_in is the node feature matrix, A_in_Dense is the dense adjacency matrix
            (NxN) (original input)
            4.A_in_Sparse is the sparse adjacency matrix COO (2xnum), RL_indice is the
            reinforcement learning index of controlled vehicles.
        """

        # 处理时序特征（先输入至GNN中进行空域编码）
        temporal_feature = []
        for elem in observation:
            X_in = torch.as_tensor(elem[0], dtype=torch.float32, device=self.device)
            # 获取邻接矩阵
            A_c_dense = torch.as_tensor(elem[1]['communication'],
                                        dtype=torch.float32, device=self.device)
            A_s_dense = torch.as_tensor(elem[1]['safety'],
                                        dtype=torch.float32, device=self.device)
            A_a_dense = torch.as_tensor(elem[1]['action'],
                                        dtype=torch.float32, device=self.device)

            # Encoder
            X = self.encoder_1(X_in)
            X = F.relu(X)
            X = self.encoder_2(X)
            X = F.relu(X)

            # 通过GCN分别处理三个邻接矩阵
            A_in_Sparse_s, _ = dense_to_sparse(A_s_dense)
            X_graph_s = self.GraphConv_safe(X, A_in_Sparse_s)
            X_graph_s = F.relu(X_graph_s)
            X_graph_s = self.GraphConv_Dense_safe(X_graph_s)
            X_graph_s = F.relu(X_graph_s)

            A_in_Sparse_a, _ = dense_to_sparse(A_a_dense)
            X_graph_a = self.GraphConv_action(X, A_in_Sparse_a)
            X_graph_a = F.relu(X_graph_a)
            X_graph_a = self.GraphConv_Dense_action(X_graph_a)
            X_graph_a = F.relu(X_graph_a)

            # 特征合并
            X_graph = X_graph_s + X_graph_a

            # 进一步基于通信邻接矩阵处理信息
            A_in_Sparse_c, _ = dense_to_sparse(A_c_dense)
            X_graph_c = self.GraphConv_com(X_graph, A_in_Sparse_c)
            X_graph_c = F.relu(X_graph_c)
            X_graph_c = self.GraphConv_Dense_com(X_graph_c)
            X_graph_c = F.relu(X_graph_c)

            # Feature concatenation
            F_concat = torch.cat((X_graph_c, X), 1)

            # 储存信息
            temporal_feature.append(F_concat)

        # 合并tensor生成最终时序特征
        temporal_feature = torch.stack(temporal_feature).unsqueeze(0)

        # 输入至时序神经网络中
        X_temporal = self.temporal_net(temporal_feature).squeeze()

        # Policy
        X_policy = self.policy_1(X_temporal)
        X_policy = F.relu(X_policy)
        X_policy = self.policy_2(X_policy)
        X_policy = F.relu(X_policy)

        # Policy and value
        pi = self.pi(X_policy)
        value = self.value(X_policy)

        # Mask
        # mask = torch.reshape(RL_indice, (self.num_agents, 1))

        # Output calculation
        # output = X_policy

        return pi, value
