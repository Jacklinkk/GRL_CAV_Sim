import torch
from GRL_Library.common import replay_buffer, explorer_discrete
from GRL_Library.agent.Discrete import DoubleDQN_agent


# Initialize GRL model
def Create_Agent(param, Graph):
    N = param['n_av']
    F = param['Feature_length'] * (param['Observe_num'] + 1)
    A = param['Action_space']
    assert isinstance(Graph, bool)
    if Graph:
        from GRL_Net.Model_GNN.GRL_Net import Graph_Model
        GRL_Net = Graph_Model(N, F, A)
    else:
        from GRL_Net.Model_GNN.GRL_Net import NonGraph_Model
        GRL_Net = NonGraph_Model(N, F, A)

    # Initialize optimizer
    optimizer = torch.optim.Adam(GRL_Net.parameters(), lr=1e-4)
    # Replay_buffer
    replay_buffer_0 = replay_buffer.ReplayBuffer(size=10 ** 6)
    # Discount factor
    gamma = 0.99
    # Initialize exploration policy
    explorer = explorer_discrete.LinearDecayEpsilonGreedy(start_epsilon=0.002, end_epsilon=0.01, decay_step=10000)

    # for parameters in GRL_Net.parameters():
    #     print("param:", parameters)

    # Initialize GRL agent
    warmup = param['Warmup_steps']  # warmup steps
    GRL_DQN = DoubleDQN_agent.DoubleDQN(
        GRL_Net,  # model
        optimizer,  # optimizer
        explorer,  # exploration policy
        replay_buffer_0,  # replay buffer
        gamma,  # discount factor
        batch_size=32,  # batch_size
        warmup_step=warmup,  # warmup steps
        update_interval=500,  # model update interval
        target_update_interval=5000,  # target model update interval
        target_update_method='soft',  # update method
        soft_update_tau=0.1,  # soft_update factor
        n_steps=1,  # multi-steps
        model_name="DQN_model"  # model name
    )

    return GRL_Net, GRL_DQN
