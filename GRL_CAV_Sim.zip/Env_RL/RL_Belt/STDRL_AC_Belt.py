import torch
from GRL_Library.agent.Discrete import AC_agent


# Initialize GRL model
def Create_Agent(param, Graph):
    N = param['n_av']
    F = param['Feature_length'] * (param['Observe_num'] + 1)
    A = param['Action_space']
    TT = param['time_length']
    assert isinstance(Graph, bool)
    from GRL_Net.Model_GNN.STGRL_AC_Net import Graph_Model
    GRL_Net = Graph_Model(N, F, A, TT)

    # Initialize optimizer
    optimizer = torch.optim.Adam(GRL_Net.parameters(), lr=1e-4)
    # Discount factor
    gamma = 0.99

    # Initialize GRL agent
    GRL_AC = AC_agent.AC(
        GRL_Net,  # model
        optimizer,  # optimizer
        gamma,  # discount factor
        model_name="DQN_model"  # model name
    )

    return GRL_Net, GRL_AC
