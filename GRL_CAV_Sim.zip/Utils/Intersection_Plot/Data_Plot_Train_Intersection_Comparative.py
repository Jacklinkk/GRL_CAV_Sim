# This python file is used to plot the result curve
import os
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d
from matplotlib.transforms import TransformedBbox
from mpl_toolkits.axes_grid1.inset_locator import BboxPatch, BboxConnector

plt.rcParams['font.sans-serif'] = ['SimHei']  # 使用黑体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题


def mark_inset(parent_axes, inset_axes, loc1a=1, loc1b=1, loc2a=2, loc2b=2, **kwargs):
    rect = TransformedBbox(inset_axes.viewLim, parent_axes.transData)

    pp = BboxPatch(rect, fill=False, **kwargs)
    parent_axes.add_patch(pp)

    p1 = BboxConnector(inset_axes.bbox, rect, loc1=loc1a, loc2=loc1b, **kwargs)
    inset_axes.add_patch(p1)
    p1.set_clip_on(False)
    p2 = BboxConnector(inset_axes.bbox, rect, loc1=loc2a, loc2=loc2b, **kwargs)
    inset_axes.add_patch(p2)
    p2.set_clip_on(False)

    return pp, p1, p2


def curve_plot_sub(data, algorithm, config, mark, linetype, linecolor):
    """
        This function is used to draw a curve

        Parameters:
        --------
        data: the data for the curve
        algorithm: the algorithm used by the model
        config: configuration of the plotting parameters
        mark: curve marker
        linetype: the line type of the curve
        linecolor: the colour of the curve
    """
    # Get configuration parameters
    linewidth = config[0]
    fontsize = config[1]
    transparency = config[2]
    color = config[3]

    # Curve plotting
    axins.fill_between(x, data[0] + data[1],
                       data[0] - data[1], alpha=transparency, color=linecolor)
    axins.plot(x, data[0], color=linecolor,
               linewidth=linewidth, linestyle=linetype[0], label=algorithm,
               marker=mark[0], markersize=mark[1])


def get_subdirs_list(base_dir):
    """
    获取指定目录下所有子目录的完整路径列表

    参数:
        base_dir (str): 基础目录路径

    返回:
        list: 包含所有子目录完整路径的列表
    """
    # 获取目录下所有子目录的名称（不包括文件）
    subdirs = [d for d in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, d))]

    # 拼接成完整路径列表
    return [os.path.join(base_dir, d) for d in subdirs]


def Data_Loader(data_dir):
    """
        This function is used to read the saved data

        Parameters:
        --------
        data_dir: the directory where the model and data are stored
    """

    # Get the directory
    Reward_dir = data_dir + "/Rewards.npy"
    Collision_dir = data_dir + "/Collision.npy"
    Average_speed_dir = data_dir + "/Average_speed.npy"
    Steps = data_dir + "/Episode_Steps.npy"

    # Read data via numpy
    Reward = np.load(Reward_dir)
    Collision = np.load(Collision_dir)
    Average_speed = np.load(Average_speed_dir)
    Steps = np.load(Steps)

    return Reward, Collision, Average_speed, Steps


def Data_Process(directories, start_step, plot_step):
    """
        This function is used to calculate the mean as well as the standard deviation
        of the data under different SAMPLES. Three samples are selected.

        data: [Reward, Collision, Average_speed]
    """
    # Load all data first
    all_data = [Data_Loader(directory) for directory in directories]
    num_samples = len(all_data)

    # 整体训练数据 - 使用列表推导式动态处理任意数量的样本
    Reward_origin = np.array([data[0][plot_step:] for data in all_data])
    Collision_origin = np.array([data[1][plot_step:] for data in all_data])
    AV_origin = np.array([data[2][plot_step:] for data in all_data])
    Steps_origin = np.array([data[3][plot_step:] for data in all_data])
    Reward_norm_origin = Reward_origin / Steps_origin

    # 训练收敛时的平稳数据
    Reward_merging = np.array([data[0][start_step:] for data in all_data])
    Collision_merging = np.array([data[1][start_step:] for data in all_data])
    AV_merging = np.array([data[2][start_step:] for data in all_data])
    Step_merging = np.array([data[3][start_step:] for data in all_data])

    # Calculate the mean of each step by column
    Reward_Average = np.average(Reward_origin, axis=0)
    Reward_Norm_Average = np.average(Reward_norm_origin, axis=0)
    Collision_Average = np.average(Collision_origin, axis=0)
    AV_Average = np.average(AV_origin, axis=0)
    Step_Average = np.average(Steps_origin, axis=0)

    # Calculate the standard deviation of each step by column
    Reward_Std = np.std(Reward_origin, axis=0)
    Reward_Norm_Std = np.std(Reward_norm_origin, axis=0)
    Collision_Std = np.std(Collision_origin, axis=0)
    AV_Std = np.std(AV_origin, axis=0)

    # Combine data into a matrix
    Data_processed_plot = [
        Reward_Norm_Average, Reward_Norm_Std,
        Reward_Average, Reward_Std,
        Collision_Average, Collision_Std,
        AV_Average, AV_Std
    ]

    # 生成评价指标用数据
    Reward_final = np.average(Reward_merging)
    Reward_std_final = np.mean(np.std(Reward_merging, axis=1))
    Collision_rate_final = np.average(Collision_merging)
    AV_final = np.average(AV_merging)
    Step_final = np.average(Step_merging)

    Reward_norm_final = Reward_final / Step_final
    Reward_norm_std_final = np.mean(Reward_Norm_Std[start_step - plot_step:])  # 注意索引调整

    Data_final = [
        Reward_norm_final, Reward_norm_std_final,
        Collision_rate_final,
        AV_final / Step_final, Step_final / 10
    ]
    Data_final = np.round(Data_final, 2).tolist()

    return Data_processed_plot, Data_final


def curve_smooth(data, sigma_r, sigma_s):
    """
        This function is used to smooth the curve to plot the data

        Parameters:
        --------
        data: data for the curve
        sigma_r: smoothing parameter for reward data
        sigma_s: smoothing parameter for standard deviation data
    """

    # Reward smoothing
    data[0] = gaussian_filter1d(data[0], sigma=sigma_r)

    # Standard deviation smoothing
    data[1] = gaussian_filter1d(data[1], sigma=sigma_s)


def curve_plot(data, algorithm, config, mark, linetype, linecolor):
    """
        This function is used to draw a curve

        Parameters:
        --------
        data: the data for the curve
        algorithm: the algorithm used by the model
        config: configuration of the plotting parameters
        mark: curve marker
        linetype: the line type of the curve
        linecolor: the colour of the curve
    """
    # Get configuration parameters
    linewidth = config[0]
    fontsize = config[1]
    transparency = config[2]
    color = config[3]

    # Curve plotting
    ax_Reward.fill_between(x, data[0] + data[1],
                           data[0] - data[1], alpha=transparency, color=linecolor)
    ax_Reward.plot(x, data[0], color=linecolor,
                   linewidth=linewidth, linestyle=linetype[0], label=algorithm,
                   marker=mark[0], markersize=mark[1])


if __name__ == '__main__':
    # ------ Data processing ------ #
    base_dir_GCQ = "Intersection_Data/Intersection_GCN/"
    data_dir_GCQ = get_subdirs_list(base_dir_GCQ)

    base_dir_AC = "Intersection_Data/Intersection_AC/"
    data_dir_AC = get_subdirs_list(base_dir_AC)

    """
        返回数据格式：
        [Reward均值，Reward标准差，
        Collision均值，Collision标准差，
        Average_Speed均值，Average_Speed标准差]
    """
    # 读取数据，计算绘图用均值和标准差，以及总的均值和标准差
    plot_step = 0
    start_step = 140
    Data_graphGCQ, Dataf_graphGCQ = Data_Process(data_dir_GCQ, start_step, plot_step)
    Data_graphAC, Dataf_graphAC = Data_Process(data_dir_AC, start_step, plot_step)


    # 计算总体评价数据
    print("GCQ:", Dataf_graphGCQ)
    print("AC:", Dataf_graphAC)

    # 曲线平滑
    sigma_r = 1.5
    sigma_s = 10.0
    curve_smooth(Data_graphGCQ, sigma_r=sigma_r, sigma_s=sigma_s)
    curve_smooth(Data_graphAC, sigma_r=sigma_r, sigma_s=sigma_s)

    # ------ Plotting curve ------ #
    # Plotting the reward curve
    fig_Reward, ax_Reward = plt.subplots(dpi=300, figsize=(4, 3.6), constrained_layout=True)

    # Defining the horizontal axis (episode)
    length = len(Data_graphGCQ[0])
    x = np.arange(1, length+1, 1)

    # Plotting curves for different algorithms
    # ------ plotting configuration ------ #
    linewidth = 1.0  # Line width
    fontsize = 10  # font size
    transparency = 0.08  # transparency
    color_shadow = "0.6"  # standard deviation shadow colour
    c = [linewidth, fontsize, transparency, color_shadow]

    marker = ['', 5]
    linetype = ['-', '--']
    line_color = ['k', 'r', 'g', 'm', 'darkorange', 'deeppink', 'sienna', 'blue']

    # ------开始绘图------ #
    # 绘制rule-based数据
    # plt.axhline(y=7.78, color=line_color[0], linestyle='--', linewidth=linewidth, label="Rule-based")
    curve_plot(Data_graphGCQ, algorithm='GCQ', config=c, mark=marker, linetype=linetype, linecolor=line_color[1])
    curve_plot(Data_graphAC, algorithm='AC', config=c, mark=marker, linetype=linetype, linecolor=line_color[2])

    # 其他配置
    plt.xticks(size=fontsize)
    plt.yticks(size=fontsize)
    ax_Reward.set_xlabel("训练轮次数", size=fontsize)
    ax_Reward.set_ylabel("归一化奖励值", size=fontsize)

    ax_Reward.set_xlim([0, length])
    ax_Reward.grid(True)
    # ax_Reward.set_title('Reward Curve of Three-Lane Road', size=fontsize)
    ax_Reward.legend(ncol=3, loc='center right', bbox_to_anchor=(1.01, 0.082), prop={'size': fontsize - 2})

    sub_plot = True
    if sub_plot:
        axins = ax_Reward.inset_axes((0.46, 0.23, 0.51, 0.30))
        # 绘制rule-based数据
        # axins.axhline(y=1.27, color=line_color[0], linestyle='--', linewidth=linewidth, label="Rule-based")
        curve_plot_sub(Data_graphGCQ, algorithm='GCQ', config=c, mark=marker, linetype=linetype,
                       linecolor=line_color[1])
        curve_plot_sub(Data_graphAC, algorithm='AC', config=c, mark=marker, linetype=linetype,
                       linecolor=line_color[2])

        # 调整子坐标系的显示范围
        axins.set_xlim(100, 150)
        axins.set_ylim(2, 9)
        axins.grid(True)
        axins.tick_params(axis='x', labelsize=fontsize - 2)
        axins.tick_params(axis='y', labelsize=fontsize - 2)
        mark_inset(ax_Reward, axins, loc1a=1, loc1b=4, loc2a=2, loc2b=3, fc="none", ec='k', lw=1, alpha=0.8)

    # Save the curve
    # plt.savefig(fname="Fig/Fig_Training/Reward_HR.jpg", dpi='figure', format="jpg")
    plt.show()

    # --------------------------------- #
    # --------------------------------- #
    # --------------------------------- #
