# This python file is used to plot the result curve
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d


def Data_Loader(data_dir):
    """
        This function is used to read the saved data

        Parameters:
        --------
        data_dir: the directory where the model and data are stored
    """

    # Get the directory
    Reward_dir = data_dir + "/Rewards.npy"
    Collision_dir = data_dir + "/Collision.npy"
    Average_speed_dir = data_dir + "/Average_speed.npy"
    Steps = data_dir + "/Episode_Steps.npy"

    # Read data via numpy
    Reward = np.load(Reward_dir)
    Collision = np.load(Collision_dir)
    Average_speed = np.load(Average_speed_dir)
    Steps = np.load(Steps)

    return Reward, Collision, Average_speed, Steps


def Mean_and_Std(method, scenario):
    """
        This function is used to calculate the mean as well as the standard deviation
        of the data under different SAMPLES. Three samples are selected.

        Parameters:
        --------
        method: the method used
        scenario: the applicable scenario
    """
    # Data directory retrieval
    gdir_1 = "Data/" + scenario + method + "/graph1"
    gdir_2 = "Data/" + scenario + method + "/graph2"
    gdir_3 = "Data/" + scenario + method + "/graph3"

    # Data loading
    g1 = Data_Loader(gdir_1)
    g2 = Data_Loader(gdir_2)
    g3 = Data_Loader(gdir_3)

    # Data merging
    Data_graph = [g1, g2, g3]
    Data_nograph = [ng1, ng2, ng3]

    # Get the length of the data list
    Length_Data = len(Data_graph)

    Reward_graph = Data_graph
    Reward_nograph = Data_nograph

    # Calculate the mean of each step by column
    Reward_Average_graph = np.average(Reward_graph, axis=0)
    Reward_Average_nograph = np.average(Reward_nograph, axis=0)

    # Calculate the standard deviation of each step by column
    Reward_Std_graph = np.std(Reward_graph, axis=0)
    Reward_Std_nograph = np.std(Reward_nograph, axis=0)

    # Combine data into a matrix
    Reward_Proceed = [Reward_Average_graph, Reward_Std_graph,
                      Reward_Average_nograph, Reward_Std_nograph]

    return Reward_Proceed


def curve_smooth(data, sigma_r, sigma_s):
    """
        This function is used to smooth the curve to plot the data

        Parameters:
        --------
        data: data for the curve
        sigma_r: smoothing parameter for reward data
        sigma_s: smoothing parameter for standard deviation data
    """

    # Reward smoothing
    data[0] = gaussian_filter1d(data[0], sigma=sigma_r)
    data[2] = gaussian_filter1d(data[2], sigma=sigma_r)

    # Standard deviation smoothing
    data[1] = gaussian_filter1d(data[1], sigma=sigma_s)
    data[3] = gaussian_filter1d(data[3], sigma=sigma_s)


def curve_plot(data, algorithm, config, mark, linetype, linecolor):
    """
        This function is used to draw a curve

        Parameters:
        --------
        data: the data for the curve
        algorithm: the algorithm used by the model
        config: configuration of the plotting parameters
        mark: curve marker
        linetype: the line type of the curve
        linecolor: the colour of the curve
    """
    # Get configuration parameters
    linewidth = config[0]
    fontsize = config[1]
    transparency = config[2]
    color = config[3]

    # Naming
    graph_name = algorithm + "_with graph"
    nograph_name = algorithm + "_wo graph"

    # Curve plotting
    ax_Reward.fill_between(x, data[0] + data[1],
                           data[0] - data[1], alpha=transparency, color=color)
    ax_Reward.fill_between(x, data[2] + data[3],
                           data[2] - data[3], alpha=transparency, color=color)
    ax_Reward.plot(x, data[0], color=line_color, linewidth=linewidth, linestyle=linetype[0],
                   label=graph_name,
                   marker=mark[0], markersize=mark[1])
    ax_Reward.plot(x, data[2], color=line_color, linewidth=linewidth, linestyle=linetype[1],
                   label=nograph_name,
                   marker=mark[0], markersize=mark[1])


if __name__ == '__main__':
    # ------ Directory element records ------ #
    # Algorithm arrays
    value_based = ["DQN", "DoubleDQN", "DuelingDQN", "DQN-NoisyNet",
                   "DQN-PER", "DistributionalDQN", "RainbowDQN"]
    policy_based = ["REINFORCE", "AC", "A2C", "NAF", "DoubleNAF",
                    "DDPG", "TD3", "PPO"]
    # Scenarios
    scenario = ["HR/", "FE/"]

    # ------ Data processing (3 samples) ------ #
    # Data reading and processing
    data_dir = "../Results_Testing/TIntersection/TIntersection_Large/Graph_Large2025_04_03-22_17_41"

    Reward, Collision, Average_speed, Step = Data_Loader(data_dir)

    # 基本数据统计
    start = 140
    mean_Reward = np.mean(Reward[start:])
    # norm_Reward = Reward[start:] / Step[start:] / (150 - start)
    std_Reward = np.std(Reward[start:])
    Collision_rate = np.sum(Collision[start:]) / (150 - start)
    mean_sum_Velocity = np.mean(Average_speed[start:])
    mean_steps = np.mean(Step[start:])
    mean_Velocity = mean_sum_Velocity / mean_steps
    norm_Reward = mean_Reward / mean_steps

    Reward_norm_plot = Reward / Step
    Reward_norm_std = np.std(Reward_norm_plot[start:])
    # print("mean_Reward:", mean_Reward)
    print("norm_Reward:", norm_Reward)
    print("std_Reward:", Reward_norm_std)
    print("Collision_rate:", Collision_rate)
    print("mean_sum_Velocity:", mean_sum_Velocity)
    print("mean_Velocity:", mean_Velocity)
    print("mean_steps:", mean_steps)

    # Data smoothing
    sigma_reward = 1.5
    sigma_std = 10.0

    Reward = gaussian_filter1d(Reward_norm_plot, sigma=sigma_reward)
    Collision = gaussian_filter1d(Collision, sigma=sigma_reward)
    Average_speed = gaussian_filter1d(Average_speed, sigma=sigma_reward)

    # ------ Plotting curve (HR) ------ #
    # Plotting the reward curve
    fig_Reward, ax_Reward = plt.subplots(dpi=240)

    # Defining the horizontal axis (episode)
    length = len(Reward)
    x = np.arange(0, length, 1)

    # Plotting curves for different algorithms
    # ------ plotting configuration ------ #
    linewidth = 1.0  # Line width
    fontsize = 10.0  # font size
    transparency = 0.2  # transparency
    color_shadow = "0.6"  # standard deviation shadow colour
    c = [linewidth, fontsize, transparency, color_shadow]

    marker = ['', 5]
    linetype = ['-', '--']
    line_color = 'b'

    ax_Reward.plot(x, Reward, color=line_color,
                   linewidth=linewidth,
                   linestyle=linetype[0],
                   label="Highway",
                   marker=marker[0],
                   markersize=marker[1])
    # # ---HR_DistributionalDQN--- #
    # marker = ['', 2]
    # linetype = '--'
    # curve_plot(HR_DistributionalDQN, "DDQN", c, marker, linetype, line_color)
    # # ---HR_REINFORCE--- #
    # marker = ['', 2]
    # linetype = ':'
    # curve_plot(HR_REINFORCE, "REINFORCE", c, marker, linetype, line_color)
    # # ---HR_AC--- #
    # marker = ['', 2]
    # linetype = ['-', '--']
    # line_color = (26/255, 40/255, 71/255)
    # curve_plot(HR_AC, "AC", c, marker, linetype, line_color)
    # # ---HR_A2C--- #
    # marker = ['', 2]
    # linetype = ['-', '--']
    # line_color = (65/255, 130/255, 164/255)
    # curve_plot(HR_A2C, "A2C", c, marker, linetype, line_color)

    plt.xticks(size=fontsize)
    plt.yticks(size=fontsize)
    ax_Reward.set_xlabel("Episode", size=fontsize)
    ax_Reward.set_ylabel("Reward", size=fontsize)
    ax_Reward.set_xlim([1, length])
    # ax_Reward.set_ylim([-500, 4000])
    ax_Reward.grid(True)
    ax_Reward.legend(loc='center right', bbox_to_anchor=(1, 0.2), prop={'size': 8})

    # Save the curve
    # plt.savefig(fname="Fig/Fig_Training/Reward_HR.jpg", dpi='figure', format="jpg")
    plt.show()

    # --------------------------------- #
    # --------------------------------- #
    # --------------------------------- #
