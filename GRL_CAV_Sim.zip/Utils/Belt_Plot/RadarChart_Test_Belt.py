import matplotlib.pyplot as plt
import numpy as np

from matplotlib.lines import Line2D

plt.rcParams['font.sans-serif'] = ['SimHei']  # 使用黑体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题


def normalize_data(data, data_ranges_compare, method='range'):
    """
    对给定数据的每一列进行归一化处理。

    参数:
        data (dict): 包含数据的字典，键为类别名称，值为数据列表。
        method (str): 归一化方法，支持 'zscore' 或 'minmax'。

    返回:
        dict: 归一化后的数据字典。
    """

    # 将数据转换为NumPy数组并转置
    data_array = np.array(list(data.values())).T
    data_range_array = np.array(list(data_ranges_compare.values()))

    # 根据指定的方法进行归一化
    normalized_columns = []
    count = 0
    for data_range, column in zip(data_range_array, data_array):
        if method == 'no_range':
            min_val = np.min(column)
            max_val = np.max(column)
            normalized_column = [(x - min_val) / (max_val - min_val) if max_val != min_val else 0 for x in column]
            count += 1
        elif method == 'range':
            min_val = np.min(data_range)
            max_val = np.max(data_range)
            if (count == 1) or (count == 2) or (count == 4) or (count == 5):
                column = max_val - column + min_val
                normalized_column = [(x - min_val) / (max_val - min_val) if max_val != min_val else 0 for x in column]
            else:
                normalized_column = [(x - min_val) / (max_val - min_val) if max_val != min_val else 0 for x in column]
            count += 1
        else:
            raise ValueError("Unsupported normalization method.")

        normalized_columns.append(normalized_column)

    # 将归一化后的数据转回字典形式
    normalized_data = {}
    keys = list(data.keys())
    for i, key in enumerate(keys):
        normalized_data[key] = [column[i] for column in normalized_columns]

    return normalized_data


# 定义绘制雷达图的函数
def Radar_Plot(evaluation_metrics, model_compare, data_compare, data_ranges_compare, data_label_compare,
               COLORS_compare):
    # ------相关参数预定义，以及图像绘制------ #
    BG_WHITE = "#fbf9f4"
    BLUE = "#2a475e"
    GREY70 = "#b3b3b3"
    GREY_LIGHT = "#f2efe8"
    # COLORS_compare = ["#FF5A5F", "#FFB400", "#007A87"]
    fontsize = 25

    # The angles at which the values of the numeric variables are placed
    LENGTH = len(evaluation_metrics)
    ANGLES = [n / LENGTH * 2 * np.pi for n in range(LENGTH)]
    ANGLES += ANGLES[:1]

    # Initialize layout ----------------------------------------------
    data_compare_norm = normalize_data(data_compare, data_ranges_compare)
    fig = plt.figure(figsize=(14, 14))
    ax = fig.add_subplot(111, polar=True)

    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)

    # Setting lower limit to negative value reduces overlap
    # for values that are 0 (the minimums)
    ax.set_ylim(-0.1, 1)

    # Plot lines and dots --------------------------------------------
    for index, (name, data) in enumerate(data_compare_norm.items()):
        data += data[:1]
        ax.plot(ANGLES, data, c=COLORS_compare[index], linewidth=2, label=name)
        ax.scatter(ANGLES, data, s=80, c=COLORS_compare[index], zorder=10)

    # ------重新绘图以进行调整------ #
    # Remove lines for radial axis (y)
    ax.set_yticks([])
    ax.yaxis.grid(False)
    ax.xaxis.grid(False)

    # 绘制雷达图中的圆形
    circle_num = 6
    circle_cor = np.linspace(0, 2 * np.pi, num=200)
    for i in range(circle_num):
        circle = np.ones(len(circle_cor)) * i * 0.2
        if i == circle_num - 1:
            ax.plot(circle_cor, circle, lw=4, c=GREY70)
        else:
            ax.plot(circle_cor, circle, lw=2, c=GREY70)

    circle_out = np.ones(len(circle_cor))
    ax.fill(circle_cor, circle_out, GREY_LIGHT)

    # 绘制不同指标的射线
    for i in ANGLES:
        ax.plot([i, i], [0, 1], lw=2, c=GREY70)

    # 标注y轴
    padding_y = 0.02
    for i, (category, ticks) in enumerate(data_label_compare.items()):
        angle = ANGLES[i]
        ticks = np.round(ticks, 2)

        # 添加注释来指示每个维度的实际范围
        count_r = 0
        for tick in ticks:
            # 计算文本位置，稍微偏移以避免重叠
            angle_text = angle
            radius_text = count_r / (circle_num - 1)
            # 添加文本标注
            ax.text(x=angle_text, y=radius_text + padding_y, s=str(tick),
                    ha='center', va='center', fontsize=fontsize - 3, zorder=100, color='black', fontweight='bold')
            count_r += 1

    # Remove spines
    ax.spines["start"].set_color("none")
    ax.spines["polar"].set_color("none")

    # ------在外圈标注评价指标并调整位置------ #
    # Set values for the angular axis (x)
    ax.set_xticks(ANGLES[:-1])
    ax.set_xticklabels(evaluation_metrics, size=fontsize)
    ax.tick_params(axis='x', which='major', pad=60)

    # 标签位置微调
    labels = ax.get_xticklabels()
    for label in labels:
        if label.get_text() == "平均速度":
            # 设置该标签的额外padding（正值向上移动）
            label.set_y(label.get_position()[1] + 0.1)  # 0.1是调整量，可根据需要修改
        if label.get_text() == "归一化\n奖励值":
            # 设置该标签的额外padding（正值向上移动）
            label.set_y(label.get_position()[1] + 0.07)

    # ------标注标签------ #
    handles = [
        Line2D(
            [], [],
            c=color,
            lw=3,
            marker="o",
            markersize=8,
            label=species
        )
        for species, color in zip(model_compare, COLORS_compare)
    ]

    legend = ax.legend(
        handles=handles,
        loc=(1.13, 0),  # bottom-right
        labelspacing=1.5,  # add space between labels
        frameon=False  # don't put a frame
    )

    # Iterate through text elements and change their properties
    for text in legend.get_texts():
        text.set_fontsize(fontsize - 3)  # Change default font size

    plt.show()


# ------设置评价指标------ #
evaluation_metrics = ['归一化\n奖励值', '标准差', '碰撞次数', '平均速度', '任务完成\n时间', '计算时间']

# ------对比实验------ #
model_compare = ['GCQ', 'AC']
data_compare = {'GCQ': [3.92, 1.13, 0.06, 9.92, 34.46, 7.12],
                'AC': [8.10, 0.22, 0.0, 14.92, 24.86, 16.42]}
data_ranges_compare = {'Reward': (3.5, 8.5),
                       'STD': (0, 1.5),
                       'Collision number': (0, 0.1),
                       'Avg.Speed': (9, 15),
                       'Time': (24, 35),
                       'Com': (7, 18)}
data_gap_compare = 6
data_label_compare = {'Reward': np.linspace(start=data_ranges_compare['Reward'][0],
                                            stop=data_ranges_compare['Reward'][1],
                                            num=data_gap_compare),
                      'STD': np.flip(np.linspace(start=data_ranges_compare['STD'][0],
                                                 stop=data_ranges_compare['STD'][1],
                                                 num=data_gap_compare)),
                      'Collision number': np.flip(np.linspace(start=data_ranges_compare['Collision number'][0],
                                                              stop=data_ranges_compare['Collision number'][1],
                                                              num=data_gap_compare)),
                      'Avg.Speed': np.linspace(start=data_ranges_compare['Avg.Speed'][0],
                                               stop=data_ranges_compare['Avg.Speed'][1],
                                               num=data_gap_compare),
                      'Time': np.flip(np.linspace(start=data_ranges_compare['Time'][0],
                                                  stop=data_ranges_compare['Time'][1],
                                                  num=data_gap_compare)),
                      'Com': np.flip(np.linspace(start=data_ranges_compare['Com'][0],
                                                 stop=data_ranges_compare['Com'][1],
                                                 num=data_gap_compare))}
# COLORS_compare = ['r', 'g', 'm', 'darkorange', 'deeppink', 'sienna', 'blue']
COLORS_compare = ['r', 'g']
Radar_Plot(evaluation_metrics, model_compare, data_compare, data_ranges_compare, data_label_compare, COLORS_compare)
