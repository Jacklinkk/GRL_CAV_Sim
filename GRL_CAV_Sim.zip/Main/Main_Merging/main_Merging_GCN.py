# 基础库
import os
import sys
import optparse
import datetime
import time

# SUMO通信库
import traci
from sumolib import checkBinary

# 数学计算库
import numpy as np

# 强化学习算法库
from Env_RL.RL_Merging.DRL_Merging import *

# 图表征库，用来提取环境信息，也是本程序研究重点
from Representation_Methods.Graph import get_feature_merging

# 数据交换库，包括奖励函数、动作执行等
from Env_DataTrans.State_Update_Merging import step_merging

# os.environ["CUDA_VISIBLE_DEVICES"] = "-1"  ###指定此处为-1即可

# 定义基本参数
Training = False
num_hv = 12
num_av = 6
num_lane = 3
n_episodes = 150
max_episode_len = 500
# 定义warmup步长
Warmup_Steps = 500

Testing = True
test_episodes = 10
load_dir = '../../Results_Testing/Merging/Merging_GCN/'
test_dir = '../../Results_Testing/Merging/Merging_GCN/'


# 配置仿真环境基本参数
def get_options():
    optParser = optparse.OptionParser()
    optParser.add_option("--nogui", action="store_true",
                         default=False, help="run the commandline version of sumo")
    options, args = optParser.parse_args()
    return options


# 定义warmup步长记录
warmup_count = 0
now_time = datetime.datetime.now()
now_time = datetime.datetime.strftime(now_time, '%Y_%m_%d-%H_%M_%S')
save_dir = 'GRL_Trained_Merging/Graph_GCN' + now_time
if not os.path.exists(save_dir):
    os.makedirs(save_dir)

# 模型训练主程序
# 场景基础信息
info_dict = {'n_vehicles': num_hv + num_av,
             'n_hv': num_hv,
             'n_av': num_av,
             'n_lanes': num_lane,
             'Max_speed_AV': 20,
             'Max_speed_HV': 20,
             'Feature_length': 4,
             'Action_space': 5,
             'Observe_range': 100,  # CAV感知范围
             'Observe_num': 3,  # 感知范围内，CAV可感知到的最大周车数量
             'Communication_distance': 120,  # CAV通信距离
             'Delta_speed': 3,  # 速度控制微元
             'Kp': 1,  # 比例控制系数
             'th': 1.2,  # 车头时距
             'Sim_step': 0.1,  # 仿真时间步长
             'Warmup_steps': Warmup_Steps,
             'com_loss': 0.01,  # 通讯丢包率
             'time_length': 5  # 时序时间长度
             }
Graph = True  # 是否调用图神经网络
if Training:
    # 设置需要储存的量
    Rewards = []  # 初始化奖励矩阵以进行数据保存
    # Loss = []  # 初始化Loss矩阵以进行数据保存
    Episode_Steps = []  # 初始化步长矩阵-保存每一episode的任务完成时的步长
    # Average_Q = []  # 初始化平均Q值矩阵保存每一episode的平均Q值
    Collision = []
    Average_speed = []
    lane_change_record = np.zeros([info_dict['n_av'], 2])  # 换道时间记录矩阵

    GRL_Net, GRL_model = Create_Agent(info_dict, Graph)

    print("#------------------------------------#")
    print("#----------Training Begins-----------#")
    print("#------------------------------------#")

    for i in range(1, n_episodes + 1):

        if 'SUMO_HOME' in os.environ:
            tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
            sys.path.append(tools)
        else:
            sys.exit("please declare environment variable 'SUMO_HOME'")

        options = get_options()
        if options.nogui:
            sumoBinary = checkBinary('sumo')
        else:
            sumoBinary = checkBinary('sumo-gui')
        traci.start(['sumo', "-c", "../../Env_Scenario/Highway_Merging.sumocfg"])
        action = np.zeros(GRL_Net.num_agents)  # 生成original动作
        list_info, _ = step_merging(action, info_dict, lane_change_record)  # 初始化环境状态

        # 动作序列记录
        action_list = np.zeros([info_dict['n_av'], info_dict['time_length']])

        obs = get_feature_merging(list_info, info_dict, action_list)  # 生成初始环境观测
        R = 0  # 行为奖励
        t = 0  # 时间步长
        collision_num = 0  # 碰撞次数记录
        av_speed = 0  # 平均车速记录

        cav_in = 0  # 设置cav在仿真环境中首次出现的标志，以辅助判断是否结束当前回合

        while True:
            # ------动作生成------ #
            if warmup_count <= Warmup_Steps:  # 进行warmup
                action = np.random.choice(
                    np.arange(GRL_Net.num_outputs), GRL_Net.num_agents)  # 生成随机动作
            else:
                action = GRL_model.choose_action(obs)  # agent与环境进行交互

            # ------记录换道时间------ #
            if isinstance(action, torch.Tensor):
                action = action.cpu().numpy()
            # 找到执行换道动作的cav
            lane_change_action = np.where((action == 3) | (action == 4))
            # 记录时间
            lane_change_record[lane_change_action, 0] \
                = lane_change_record[lane_change_action, 1]
            lane_change_record[lane_change_action, 1] = traci.simulation.getTime()

            # 这里根据算法生成的动作集合，对环境中车辆状态进行更新，并将更新后的状态信息进行存储
            state_next, reward = step_merging(action, info_dict, lane_change_record)

            # 这部分用来根据当前交通环境信息，构建更新后的图表征，并将其更新为下一时刻的观测
            obs_next = get_feature_merging(state_next, info_dict, action_list)

            # ------换道时间进一步处理------ #
            # 这里完成了对换道次数的处理，因此需重置换道记录矩阵
            lane_change_record[lane_change_action, 0] = 0

            # 记录相关训练数据
            R += reward
            t += 1
            warmup_count += 1
            collision_num += state_next['collision_num']
            av_speed += state_next['average_speed']

            # 判断是否done
            exist_cav = len(state_next['ID_AVs'])
            if exist_cav:
                cav_in += 1
            done = (cav_in and (exist_cav == 0)) or (t == max_episode_len)
            # ------将交互结果储存到经验回放池中------ #
            if exist_cav:  # 环境内没有cav就没必要储存经验回放结果
                GRL_model.store_transition(obs, action, reward, obs_next, done)
            # ------进行策略更新------ #
            GRL_model.learn()
            # ------环境观测更新------ #
            obs = obs_next
            # traci.simulationStep()
            if done:
                break

        traci.close()
        # ------记录训练数据------ #
        # 获取训练数据
        training_data = GRL_model.get_statistics()
        loss = training_data[0]
        q = training_data[1]
        # 记录训练数据
        Rewards.append(R)  # 记录Rewards
        Collision.append(collision_num)  # 记录碰撞次数
        Average_speed.append(av_speed)  # 记录平均车速
        Episode_Steps.append(t)  # 记录Steps
        # Loss.append(loss)  # 记录loss
        # Average_Q.append(q)  # 记录平均Q值

        if i % 1 == 0:
            print('Training Episode:', i, 'Reward:', R, 'Loss:', loss,
                  'Collision:', collision_num,
                  'Average_speed:', av_speed,
                  'Episode_steps:', t)

    print('Training Finished.')
    # 模型保存
    GRL_model.save_model(save_dir)
    # 保存训练过程中的各项数据
    np.save(save_dir + "/Rewards", Rewards)
    np.save(save_dir + "/Collision", Collision)
    np.save(save_dir + "/Average_speed", Average_speed)
    np.save(save_dir + "/Episode_Steps", Episode_Steps)

if Testing:
    # 设置需要储存的量
    Rewards = []  # 初始化奖励矩阵以进行数据保存
    # Loss = []  # 初始化Loss矩阵以进行数据保存
    Episode_Steps = []  # 初始化步长矩阵-保存每一episode的任务完成时的步长
    # Average_Q = []  # 初始化平均Q值矩阵保存每一episode的平均Q值
    Collision = []
    Average_speed = []
    computing_time = []
    com_cost = []
    test_results = []

    # 模型加载
    model_dir = "Graph_GCN2024_09_07-13_44_07"
    load_dir = load_dir + model_dir
    GRL_Net, GRL_model = Create_Agent(info_dict, Graph)
    GRL_model.load_model(load_dir)

    print("#-------------------------------------#")
    print("#-----------Testing Begins------------#")
    print("#-------------------------------------#")
    for i in range(1, test_episodes + 1):

        if 'SUMO_HOME' in os.environ:
            tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
            sys.path.append(tools)
        else:
            sys.exit("please declare environment variable 'SUMO_HOME'")

        options = get_options()
        if options.nogui:
            sumoBinary = checkBinary('sumo')
        else:
            sumoBinary = checkBinary('sumo-gui')
        traci.start(['sumo', "-c", "../../Env_Scenario/Highway_Merging.sumocfg"])

        # 换道时间记录矩阵
        lane_change_record = np.zeros([info_dict['n_av'], 2])

        action = np.zeros(GRL_Net.num_agents)  # 生成original动作
        list_info, _ = step_merging(action, info_dict, lane_change_record)  # 初始化环境状态

        # 动作序列记录
        action_list = np.zeros([info_dict['n_av'], info_dict['time_length']])
        obs = get_feature_merging(list_info, info_dict, action_list)  # 生成初始环境观测
        R = 0  # 行为奖励
        t = 0  # 时间步长
        collision_num = 0  # 碰撞次数记录
        av_speed = 0  # 平均车速记录
        com_e_total = 0  # 平均通信能耗记录

        cav_in = 0  # 设置cav在仿真环境中首次出现的标志，以辅助判断是否结束当前回合
        start_time = time.time()

        while True:

            # ------动作生成------ #
            action = GRL_model.choose_action(obs)  # agent与环境进行交互、

            # ------记录换道时间（从第一次换道开始）------ #
            if isinstance(action, torch.Tensor):
                action = action.cpu().numpy()
            # 找到执行换道动作的cav
            lane_change_action = np.where((action == 3) | (action == 4))
            # 记录时间
            lane_change_record[lane_change_action, 0] \
                = lane_change_record[lane_change_action, 1]
            lane_change_record[lane_change_action, 1] = traci.simulation.getTime()

            # 这里根据算法生成的动作集合，对环境中车辆状态进行更新，并将更新后的状态信息进行存储
            state_next, reward = step_merging(action, info_dict, lane_change_record)

            # 这部分用来根据当前交通环境信息，构建更新后的图表征，并将其更新为下一时刻的观测
            obs_next = get_feature_merging(state_next, info_dict, action_list)

            # ------换道时间进一步处理------ #
            # 这里完成了对换道次数的处理，因此需重置换道记录矩阵
            lane_change_record[lane_change_action, 0] = 0

            # 计算通信能耗
            num_cav = len(state_next['ID_AVs'])
            com_e = num_cav * (num_cav - 1) * (1 + 1) * 1e-3

            # 记录相关训练数据
            R += reward
            t += 1
            warmup_count += 1
            collision_num += state_next['collision_num']
            av_speed += state_next['average_speed']
            com_e_total += com_e

            # 判断是否done
            exist_cav = len(state_next['ID_AVs'])
            if exist_cav:
                cav_in += 1
            done = (cav_in and (exist_cav == 0)) or (t == max_episode_len)
            # ------环境观测更新------ #
            obs = obs_next
            # traci.simulationStep()
            if done:
                break

        end_time = time.time()
        traci.close()
        # ------记录测试数据------ #
        # 记录测试数据
        Rewards.append(R)  # 记录Rewards
        Collision.append(collision_num)  # 记录碰撞次数
        Average_speed.append(av_speed)  # 记录平均车速
        Episode_Steps.append(t)  # 记录Steps
        computing_time.append(end_time - start_time)
        com_cost.append(com_e_total)
        test_results = [Rewards, Collision, Average_speed, Episode_Steps, computing_time, com_cost]
        # Loss.append(loss)  # 记录loss
        # Average_Q.append(q)  # 记录平均Q值

        if i % 1 == 0:
            print('Testing_Episode:', i, 'Reward:', R,
                  'Collision:', collision_num,
                  'Average_speed:', av_speed,
                  'Episode_steps:', t,
                  "com_cost:", com_e_total,
                  "computing_time:", (end_time - start_time) / t * 1000)
    print('Evaluation Finished')

    # 测试数据保存
    if not os.path.exists(test_dir + "Test"):
        os.makedirs(test_dir + "Test")
    np.save(test_dir + "Test/" + model_dir + "+" + now_time, test_results)
